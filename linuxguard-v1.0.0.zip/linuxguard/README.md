# LinuxGuard

**Read-only Linux security auditing in pure Bash.** LinuxGuard inspects a host (or an offline root filesystem), classifies every issue as **Critical / High / Medium / Low**, and writes a clean **Markdown security report** with evidence and remediation steps.

[![CI](https://github.com/DanFX-codes/linuxguard/actions/workflows/ci.yml/badge.svg)](https://github.com/DanFX-codes/linuxguard/actions)
![License: MIT](https://img.shields.io/badge/license-MIT-green)
![Bash 4.2+](https://img.shields.io/badge/bash-4.2%2B-blue)

- No dependencies beyond Bash, coreutils, `find`, `grep`, `sed`, `awk` (standard on every distro)
- **Never modifies the system** - every check only reads
- Works on Debian/Ubuntu and RHEL/Fedora families; no install step
- CI-friendly: `--fail-on high` returns a non-zero exit code
- Tested: 90 assertions against synthetic vulnerable and hardened systems

## What it checks

| Module | ID prefix | Highlights |
|---|---|---|
| User & privilege auditing | `USR` | extra UID 0 accounts, empty passwords, duplicate UIDs, service accounts with shells, weak hashes (MD5/DES), `NOPASSWD` sudo, admin-group size, password aging |
| File permission auditing | `PRM` | permissions/ownership of `passwd`, `shadow`, `sudoers`, `sshd_config`; world-writable files and directories; unexpected SUID/SGID (incl. in `/home`, `/tmp`); open home directories |
| Network & port inspection | `NET` | listening sockets via `ss`, classified by service risk (telnet, FTP, SMB, databases, RDP/VNC, Docker API...); sysctl hardening (ASLR, SYN cookies, source routing, forwarding) |
| SSH security auditing | `SSH` | root login, empty/password auth, protocol 1, weak ciphers/MACs/KEX, `MaxAuthTries`, grace time, allow-lists, key-file permissions, root `authorized_keys`; honours `Include`, uses `sshd -T` when available |
| Firewall & service auditing | `FWS` | ufw / firewalld / nftables / iptables state and default policy; risky running services; fail2ban/auditd presence |
| Authentication log analysis | `AUTH` | brute-force sources, **brute force followed by a successful login**, root targeting, user enumeration, sudo/su failures, new accounts, break-in warnings |

The full list of 51 checks is in [docs/CHECKS.md](docs/CHECKS.md).

## Quick start

```bash
git clone https://github.com/DanFX-codes/linuxguard.git
cd linuxguard
sudo ./linuxguard.sh            # full audit; report goes to ./reports/
```

Run as root for complete results. Without root, LinuxGuard still runs and lists skipped checks under *Notes and limitations* in the report.

```text
LinuxGuard summary
  Overall risk : CRITICAL
  Score        : 0/100
  Critical 9  High 13  Medium 18  Low 10  (passed checks: 1)
  Report       : ./reports/linuxguard-vulnbox-20261114-101500.md
```

See a complete example in [examples/sample-report.md](examples/sample-report.md).

## Usage

```text
./linuxguard.sh [options]

  -o, --output FILE     Markdown report path (default ./reports/linuxguard-<host>-<timestamp>.md)
  -m, --modules LIST    users,perms,network,ssh,firewall,authlog (default: all)
      --fail-on LEVEL   exit 1 if a finding of LEVEL or above exists (critical|high|medium|low)
      --root DIR        audit an offline root filesystem (mounted disk, image, container rootfs)
  -q, --quiet           no progress output
      --no-color        disable colours
  -h, --help / -V, --version
```

| Exit code | Meaning |
|---|---|
| 0 | audit completed (and nothing at/above `--fail-on`) |
| 1 | at least one finding at/above `--fail-on` |
| 2 | usage error |
| 3 | runtime error (unsupported OS, report not writable) |

**Environment:** `LG_BRUTE_THRESHOLD` (default `10`) - failed logins per source IP before it is reported as brute force; ≥5× the threshold is High.

### Examples

```bash
sudo ./linuxguard.sh -m ssh,authlog                 # only SSH hardening + log analysis
sudo ./linuxguard.sh --fail-on high -q -o audit.md  # use in a cron job / CI gate
sudo ./linuxguard.sh --root /mnt/disk-image         # forensic / golden-image audit
LG_BRUTE_THRESHOLD=5 sudo ./linuxguard.sh -m authlog
```

## Risk classification and scoring

| Severity | Meaning | Score penalty |
|---|---|---|
| **Critical** | Direct path to full compromise or active compromise indicators | -25 |
| **High** | Serious weakness that is likely exploitable | -10 |
| **Medium** | Meaningful weakness / missing hardening | -4 |
| **Low** | Best-practice deviation or informational exposure | -1 |

The score starts at 100 (minimum 0). The overall risk label is the highest severity present.

## Report layout

Executive summary (overall risk, score, severity counts, *Fix first* list) → results by module → findings grouped by severity, each with description, remediation and evidence → passed checks → notes/limitations → methodology.

## Offline audits and the runtime snapshot

`--root DIR` reads every file under `DIR` (`/etc`, `/var/log`, home directories...). Runtime state (listening ports, firewall rules, running services, `sshd -T`) cannot come from a disk, so those checks run only if a snapshot directory `DIR/_cmd/` exists containing captured command output (`ss`, `ufw`, `nft`, `iptables`, `firewall_cmd`, `systemctl_running`, `sshd_T`). Otherwise they are skipped and reported in the notes - never guessed. Ownership checks are also skipped offline because UIDs on a mounted image may not map to this host. The test-suite uses this mechanism.

## Development

```bash
bash tests/run_tests.sh      # 90 assertions, ~5 seconds
make lint                    # shellcheck (if installed)
make test
```

Architecture, module contract and "how to add a check" are in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

```text
linuxguard.sh        CLI entry point
lib/common.sh        finding registry, scoring, helpers
lib/{users,perms,network,ssh,firewall,authlog}.sh   audit modules
lib/authlog.awk      log analyser
lib/report.sh        Markdown report generator
tests/               fixtures + test runner
docs/                architecture and check catalogue
```

## Limitations (MVP)

- Findings are heuristics; always review evidence before acting. Expected services (for example a database on a private host) may be flagged.
- sshd `Match` blocks are ignored by the file parser (use root + `sshd -T` for effective values).
- Auth-log analysis covers sshd, sudo, su and useradd lines in syslog format, over whatever the log files retain.
- Linux only; GNU `stat`/`find` required. IPv6 firewall rules are not evaluated separately.

## Roadmap

JSON/SARIF output, `--snapshot` to capture a runtime snapshot, PAM/password-policy checks, kernel module and mount-option checks, CIS benchmark mapping, container-aware mode.

## Responsible use

Run LinuxGuard only on systems you own or are authorised to assess.

## License

MIT - see [LICENSE](LICENSE).
