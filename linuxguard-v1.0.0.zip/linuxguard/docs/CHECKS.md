# Check catalogue

Severity shown is the highest the check can emit. "Offline" = runs with `--root` without a runtime snapshot.

| ID | Module | Check | Severity | Offline |
|---|---|---|---|---|
| USR-001 | users | Non-root account with UID 0 | Critical | yes |
| USR-002 | users | Duplicate UIDs | Medium | yes |
| USR-003 | users | System accounts (UID<1000) with login shell | Medium | yes |
| USR-004 | users | Empty password in /etc/shadow | Critical | yes |
| USR-005 | users | MD5-crypt / DES password hashes | Medium | yes |
| USR-006 | users | NOPASSWD / !authenticate in sudoers | High | yes |
| USR-007 | users | More than 3 members in sudo/wheel/admin | Low | yes |
| USR-008 | users | PASS_MAX_DAYS > 365 | Low | yes |
| PRM-001 | perms | passwd/group/shadow/gshadow/sudoers/sshd_config/crontab/opasswd permissions | Critical | yes |
| PRM-002 | perms | Critical file not owned by root | High | no (live only) |
| PRM-003 | perms | World-writable files in system directories | High | yes |
| PRM-004 | perms | SUID/SGID in user-writable locations | High | yes |
| PRM-005 | perms | Non-allow-listed SUID/SGID binaries | Medium | yes |
| PRM-006 | perms | World-writable directories without sticky bit | High | yes |
| PRM-007 | perms | World-writable home directories | High | yes |
| PRM-008 | perms | Group-writable home directories | Medium | yes |
| PRM-009 | perms | Home directories readable by others | Low | yes |
| NET-001 | network | Risky service exposed on a non-loopback address | Critical | snapshot |
| NET-002 | network | Unreviewed externally listening services | Low | snapshot |
| NET-003 | network | ASLR not fully enabled | Medium | snapshot |
| NET-004 | network | TCP SYN cookies disabled | Medium | snapshot |
| NET-005 | network | Source routing accepted | Medium | snapshot |
| NET-006 | network | IPv4 forwarding enabled | Low | snapshot |
| SSH-001 | ssh | PermitRootLogin | Critical | yes |
| SSH-002 | ssh | PermitEmptyPasswords | Critical | yes |
| SSH-003 | ssh | PasswordAuthentication | Medium | yes |
| SSH-004 | ssh | Protocol 1 | Critical | yes |
| SSH-005 | ssh | HostbasedAuthentication / PermitUserEnvironment | High | yes |
| SSH-006 | ssh | MaxAuthTries | Medium | yes |
| SSH-007 | ssh | X11Forwarding | Low | yes |
| SSH-008 | ssh | Weak ciphers / MACs / KEX | High | yes |
| SSH-009 | ssh | LoginGraceTime | Medium | yes |
| SSH-010 | ssh | AllowUsers/AllowGroups absent | Low | yes |
| SSH-011 | ssh | Private key permissions | High | yes |
| SSH-012 | ssh | authorized_keys group/world-writable | High | yes |
| SSH-013 | ssh | Root authorized_keys present | Medium | yes |
| FWS-001 | firewall | No active host firewall | High | snapshot |
| FWS-002 | firewall | Permissive default inbound policy | Medium | snapshot |
| FWS-003 | firewall | Risky services running | Critical | snapshot |
| FWS-004 | firewall | No fail2ban/sshguard/crowdsec | Low | snapshot |
| FWS-005 | firewall | auditd not running | Low | snapshot |
| AUTH-001 | authlog | Brute-force source later logged in successfully (otherwise: no source reached threshold = pass) | Critical | yes |
| AUTH-002 | authlog | High-volume brute force (≥5× threshold) | High | yes |
| AUTH-003 | authlog | Brute-force sources (≥ threshold) | Medium | yes |
| AUTH-004 | authlog | Repeated failed logins for root | Medium | yes |
| AUTH-005 | authlog | Root logged in with a password | High | yes |
| AUTH-006 | authlog | Invalid-user probing | Medium | yes |
| AUTH-007 | authlog | sudo authentication failures | Medium | yes |
| AUTH-008 | authlog | su authentication failures | Medium | yes |
| AUTH-009 | authlog | New accounts created in log window | Low | yes |
| AUTH-010 | authlog | sshd POSSIBLE BREAK-IN ATTEMPT | High | yes |
