# LinuxGuard Architecture

## Goals

1. **Read-only and safe** - an auditor must never become a risk. No check writes, restarts or changes anything.
2. **Zero dependencies** - Bash plus tools present on any Linux install.
3. **Deterministic and testable** - every check can run against a synthetic filesystem.
4. **Honest** - when a check cannot run (no root, no systemd, offline), it is recorded as a *note*, never silently passed or guessed.

## Component overview

```mermaid
flowchart LR
  CLI[linuxguard.sh<br/>arg parsing, orchestration] --> M1[users.sh]
  CLI --> M2[perms.sh]
  CLI --> M3[network.sh]
  CLI --> M4[ssh.sh]
  CLI --> M5[firewall.sh]
  CLI --> M6[authlog.sh + authlog.awk]
  M1 & M2 & M3 & M4 & M5 & M6 --> REG[(common.sh<br/>finding registry)]
  REG --> SCORE[scoring]
  REG --> REP[report.sh] --> MD[Markdown report]
  SCORE --> EXIT[exit code / --fail-on]
```

Execution flow: parse options → resolve audit root → run selected modules in order → each module registers **findings**, **passes** and **notes** in the registry → `report.sh` renders Markdown → summary is printed and `--fail-on` decides the exit code.

## The environment seam (`LG_ROOT`)

All modules read the system through one seam, which is what makes the tool testable and enables offline audits:

| Need | Live system (`LG_ROOT=""`) | Offline / test (`LG_ROOT=/dir`) |
|---|---|---|
| Files | `/etc/passwd` | `$LG_ROOT/etc/passwd` |
| Command output | `lg_run ss ss -tulnp` executes `ss` | `lg_run ss ...` prints `$LG_ROOT/_cmd/ss` |
| Runtime available? | always | only if `$LG_ROOT/_cmd/` exists |

Modules therefore always write paths as `"$LG_ROOT/etc/..."` and call `lg_run <name> <cmd...>` for commands. They never call `ss`, `ufw` etc. directly.

## Data model

A finding is one record in the `LG_FINDINGS` array, fields joined by an ASCII Unit Separator (`\037`, so no text can collide):

```
SEVERITY ␟ module ␟ ID ␟ title ␟ description ␟ remediation ␟ evidence
```

Newlines in evidence are stored as Record Separator (`\036`) so a record always stays on one line and is turned back into a code block by the report. Passed checks (`LG_PASSED`) and notes (`LG_NOTES`) use the same scheme. Per-module counters live in `LG_MOD_COUNT["module:SEVERITY"]`.

An **ID identifies a check**, not an instance: a check that finds several affected objects may emit several findings with the same ID (for example `PRM-001` once per bad file), each with its own evidence.

## Module contract

A module is a file `lib/<name>.sh` exposing `audit_<name>()` and registered in `linuxguard.sh`:

```bash
audit_example() {
  lg_module_begin example "Example Auditing"        # registers the module title
  lg_runtime_available || { lg_note "..."; return 0; }
  if bad_condition; then
    lg_finding HIGH EXA-001 "Title" "Why it matters" "How to fix" "evidence lines"
  else
    lg_pass EXA-001 "What was verified"
  fi
}
```

Rules: (1) read-only; (2) always go through `$LG_ROOT` / `lg_run`; (3) never `exit` - return; (4) avoid pipes into `while` loops that mutate registry state (subshell); use `done <<<"$var"` or process substitution; (5) emit a pass or a note for every check so reports account for everything.

## Risk classification and scoring

Severity is assigned by the check with a fixed rationale:

- **Critical** - immediate full compromise or an indicator of compromise (extra UID 0, empty passwords, world-readable `shadow`, brute force followed by a login, cleartext telnet).
- **High** - exploitable weakness (passwordless sudo, SUID in `/home`, exposed databases, no firewall).
- **Medium** - weakness that needs another factor (password SSH auth, ASLR off, risky legacy services).
- **Low** - hygiene and exposure notes.

`score = max(0, 100 − 25·C − 10·H − 4·M − 1·L)`; overall label = highest severity present. Weights live in `LG_WEIGHT` (`common.sh`).

## Notable design decisions

- **sshd configuration** - when runtime is available `sshd -T` gives the effective configuration (including `Match` defaults and OpenSSH defaults). Otherwise `_ssh_parse_file` parses `sshd_config` with "first match wins" semantics, follows `Include`, and stops at `Match`.
- **Log analysis in awk** - `authlog.awk` aggregates in one pass (POSIX awk, works on mawk/gawk/busybox) and emits tab-separated records; Bash only classifies the aggregates. This keeps multi-hundred-MB logs fast.
- **Correlation** - AUTH-001 joins failed-login sources with *successful* logins from the same IP; this is the highest-value signal in the log module.
- **SUID allow-list** - `_perms_suid_allowed` lists common distro binaries; anything else is Medium, anything in `/home`, `/tmp`, `/var/tmp`, `/dev/shm`, `/srv`, `/var/www` is High.
- **Bounded scans** - `find` uses `-xdev`, targeted directories and `head` caps to keep runtime and report size predictable.

## Testing strategy

`tests/fixtures.sh` builds two synthetic root filesystems at test time (permissions are applied by the script because Git does not preserve them):

- **insecure** - one instance of nearly every issue; the suite asserts the expected ID *and severity* for each.
- **hardened** - a clean system; asserts **zero findings** and score 100 (guards against false positives).

Further tests cover CLI exit codes, module selection, offline-without-snapshot behaviour, thresholds, report structure, and unit tests of helpers (`lg_mode_exceeds`, `_net_classify`, SSH parser, scoring). Run with `bash tests/run_tests.sh`.

## Adding a check - checklist

1. Add the check to the module (finding + pass path).
2. Pick the ID (`<PREFIX>-<next number>`) and add it to `docs/CHECKS.md`.
3. Add the condition to the insecure fixture and an `expect` line in `tests/run_tests.sh`; make sure the hardened fixture still produces zero findings.
4. `bash tests/run_tests.sh`.

## Security considerations of the tool itself

- Reports contain sensitive data (usernames, IPs, paths, config). They are written with the user's umask; treat them as confidential (`chmod 600 reports/*`).
- No network access is performed; nothing is uploaded.
- Password hashes are never printed - only account names.
