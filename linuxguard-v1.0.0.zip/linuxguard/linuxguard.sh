#!/usr/bin/env bash
# LinuxGuard - read-only Linux security auditing toolkit.
# Usage: ./linuxguard.sh [options]   (see --help)
set -u
set -o pipefail

if (( BASH_VERSINFO[0] < 4 || (BASH_VERSINFO[0] == 4 && BASH_VERSINFO[1] < 2) )); then
  echo "LinuxGuard requires bash >= 4.2 (found $BASH_VERSION)" >&2; exit 3
fi

_src=${BASH_SOURCE[0]}
LG_HOME=$(cd "$(dirname "$(readlink -f "$_src")")" && pwd)
export LG_HOME

# shellcheck source=lib/common.sh
source "$LG_HOME/lib/common.sh"
for _m in users perms network ssh firewall authlog report; do
  # shellcheck source=/dev/null
  source "$LG_HOME/lib/$_m.sh"
done

LG_ALL_MODULES=(users perms network ssh firewall authlog)
declare -A LG_MODULE_FN=([users]=audit_users [perms]=audit_perms [network]=audit_network
                         [ssh]=audit_ssh [firewall]=audit_firewall [authlog]=audit_authlog)

usage() {
  cat <<USAGE
LinuxGuard v$LG_VERSION - read-only Linux security audit

Usage: $(basename "$_src") [options]

Options:
  -o, --output FILE     Markdown report path (default: ./reports/linuxguard-<host>-<timestamp>.md)
  -m, --modules LIST    Comma-separated modules to run (default: all)
                        modules: ${LG_ALL_MODULES[*]}
      --fail-on LEVEL   Exit 1 if a finding of LEVEL or above exists
                        (critical|high|medium|low). Default: never fail.
      --root DIR        Audit an offline root filesystem instead of the live system
  -q, --quiet           Suppress progress output
      --no-color        Disable coloured output
  -h, --help            Show this help
  -V, --version         Show version

Environment:
  LG_BRUTE_THRESHOLD    Failed logins per IP that count as brute force (default 10)

Exit codes: 0 success | 1 findings at/above --fail-on | 2 usage error | 3 runtime error
Run as root for complete results (shadow, sudoers, firewall state, auth logs).
USAGE
}

die_usage() { lg_err "$1"; echo "Try --help." >&2; exit 2; }

OUTPUT="" MODULES="" FAIL_ON=""
while (( $# )); do
  case $1 in
    -o|--output)  [[ $# -ge 2 ]] || die_usage "$1 needs a value"; OUTPUT=$2; shift 2 ;;
    -m|--modules) [[ $# -ge 2 ]] || die_usage "$1 needs a value"; MODULES=$2; shift 2 ;;
    --fail-on)    [[ $# -ge 2 ]] || die_usage "$1 needs a value"; FAIL_ON=${2^^}; shift 2 ;;
    --root)       [[ $# -ge 2 ]] || die_usage "$1 needs a value"; LG_ROOT=$2; shift 2 ;;
    -q|--quiet)   LG_QUIET=1; shift ;;
    --no-color)   LG_NO_COLOR=1; shift ;;
    -h|--help)    usage; exit 0 ;;
    -V|--version) echo "LinuxGuard $LG_VERSION"; exit 0 ;;
    *)            die_usage "Unknown option: $1" ;;
  esac
done

lg_color_init

if [[ -n $FAIL_ON && -z ${LG_RANK[$FAIL_ON]:-} ]]; then
  die_usage "Invalid --fail-on level '$FAIL_ON' (use critical|high|medium|low)"
fi
if [[ -n $LG_ROOT && $LG_ROOT != / ]]; then
  [[ -d $LG_ROOT ]] || die_usage "--root '$LG_ROOT' is not a directory"
  LG_ROOT=$(cd "$LG_ROOT" && pwd)
fi
LG_ROOT=${LG_ROOT%/}

selected=()
if [[ -z $MODULES ]]; then
  selected=("${LG_ALL_MODULES[@]}")
else
  IFS=, read -ra selected <<<"$MODULES"
  for _m in "${selected[@]}"; do
    [[ -n ${LG_MODULE_FN[$_m]:-} ]] || die_usage "Unknown module '$_m' (available: ${LG_ALL_MODULES[*]})"
  done
fi

if [[ -z $LG_ROOT ]]; then
  [[ $(uname -s) == Linux ]] || { lg_err "LinuxGuard audits Linux systems only."; exit 3; }
  (( EUID == 0 )) || lg_warn "Not running as root - some checks will be limited (see report notes)."
fi

if [[ -z $OUTPUT ]]; then
  _host=$(hostname 2>/dev/null || echo host)
  OUTPUT="./reports/linuxguard-${_host}-$(date +%Y%m%d-%H%M%S).md"
fi
mkdir -p "$(dirname "$OUTPUT")" 2>/dev/null || { lg_err "Cannot create directory for $OUTPUT"; exit 3; }

lg_info "LinuxGuard v$LG_VERSION starting (${LG_ROOT:+offline: $LG_ROOT}${LG_ROOT:-live system})"
for _m in "${selected[@]}"; do "${LG_MODULE_FN[$_m]}"; done

lg_write_report "$OUTPUT" || { lg_err "Failed to write report to $OUTPUT"; exit 3; }

if (( ! LG_QUIET )); then
  {
    echo
    echo "${C_BLD}LinuxGuard summary${C_RST}"
    printf '  Overall risk : %s\n  Score        : %s/100\n' "$(lg_overall)" "$(lg_score)"
    printf '  %sCritical%s %d  %sHigh%s %d  %sMedium%s %d  %sLow%s %d  (passed checks: %d)\n' \
      "$C_RED" "$C_RST" "${LG_COUNT[CRITICAL]}" "$C_RED" "$C_RST" "${LG_COUNT[HIGH]}" \
      "$C_YEL" "$C_RST" "${LG_COUNT[MEDIUM]}" "$C_BLU" "$C_RST" "${LG_COUNT[LOW]}" "$LG_PASS_TOTAL"
    printf '  Report       : %s\n' "$OUTPUT"
  } >&2
fi

if [[ -n $FAIL_ON ]] && lg_any_at_least "$FAIL_ON"; then exit 1; fi
exit 0
