#!/usr/bin/env bash
# LinuxGuard module: authentication log analysis (AUTH-xxx)
# shellcheck shell=bash

# Sort "count<TAB>text" lines by count (desc), keep top N, drop the count.
_auth_top() { sort -t$'\t' -k1,1nr | head -n "${1:-10}" | cut -f2-; }

audit_authlog() {
  lg_module_begin authlog "Authentication Log Analysis"
  local threshold=${LG_BRUTE_THRESHOLD:-10}
  [[ $threshold =~ ^[0-9]+$ ]] && (( threshold > 0 )) || threshold=10

  local files=() f summary="" src=""
  for f in "$LG_ROOT/var/log/auth.log" "$LG_ROOT/var/log/auth.log.1" \
           "$LG_ROOT/var/log/secure" "$LG_ROOT"/var/log/secure-*; do
    [[ -f $f && -r $f ]] && files+=("$f")
  done
  if (( ${#files[@]} )); then
    summary=$(awk -f "$LG_HOME/lib/authlog.awk" "${files[@]}")
    src=$(lg_strip_root "${files[*]}")
  else
    local j
    j=$(lg_run journalctl journalctl --no-pager -q -u ssh -u sshd -u sudo -n 50000)
    if [[ -n $j ]]; then
      summary=$(awk -f "$LG_HOME/lib/authlog.awk" <<<"$j"); src="systemd journal"
    fi
  fi
  if [[ -z $summary ]]; then
    lg_note "No readable authentication log (/var/log/auth.log, /var/log/secure, journal) - log analysis skipped."
    return 0
  fi

  local kind a b c d total_fail=0 root_fail=0 invalid_total=0 sudo_fail=0 su_fail=0 breakin=0
  local root_pw="" new_users="" inv_lines="" fail_lines=""
  declare -A fail_ip=() accepted_ip=()
  while IFS=$'\t' read -r kind a b c d; do
    case $kind in
      TOTAL_FAIL) total_fail=$a ;;
      ROOT_FAIL) root_fail=$a ;;
      INVALID_TOTAL) invalid_total=$a ;;
      SUDO_FAIL) sudo_fail=$a ;;
      SU_FAIL) su_fail=$a ;;
      BREAKIN) breakin=$a ;;
      FAIL_IP) fail_ip[$a]=$b ;;
      INVALID_USER) inv_lines+="$b"$'\t'"$a ($b attempts)"$'\n' ;;
      NEW_USER) new_users+="$a"$'\n' ;;
      ACCEPT)
        accepted_ip[$b]+="$a/$c "
        [[ $a == root && $c == password ]] && root_pw+="root logged in with a password from $b ($d time(s))"$'\n' ;;
    esac
  done <<<"$summary"
  lg_note "Analysed $src: $total_fail failed SSH logins, $invalid_total invalid-user probes (brute-force threshold: $threshold failures per IP)."

  # --- brute force by source IP, correlated with successful logins
  local ip n crit="" high="" med=""
  for ip in "${!fail_ip[@]}"; do
    n=${fail_ip[$ip]}
    (( n >= threshold )) || continue
    if [[ -n ${accepted_ip[$ip]:-} ]]; then
      crit+="$n"$'\t'"$ip: $n failed logins followed by a SUCCESSFUL login (${accepted_ip[$ip]% })"$'\n'
    elif (( n >= threshold * 5 )); then
      high+="$n"$'\t'"$ip: $n failed logins"$'\n'
    else
      med+="$n"$'\t'"$ip: $n failed logins"$'\n'
    fi
  done
  if [[ -n $crit ]]; then
    lg_finding CRITICAL AUTH-001 "Successful login from an IP with brute-force history" \
      "A source that hammered SSH with failures later authenticated - the account may have been guessed." \
      "Treat as a probable compromise: kill sessions, rotate credentials, review ~/.ssh/authorized_keys, cron and new users, then block the IP." \
      "$(_auth_top 10 <<<"$crit")"
  fi
  if [[ -n $high ]]; then
    lg_finding HIGH AUTH-002 "High-volume SSH brute-force sources" \
      "These addresses made at least $(( threshold * 5 )) failed attempts each." \
      "Block at the firewall, enable fail2ban/sshguard, and move to key-only authentication." \
      "$(_auth_top 10 <<<"$high")"
  fi
  if [[ -n $med ]]; then
    lg_finding MEDIUM AUTH-003 "SSH brute-force sources detected" \
      "These addresses made at least $threshold failed attempts each." \
      "Enable fail2ban/sshguard and disable password authentication." "$(_auth_top 10 <<<"$med")"
  fi
  [[ -z $crit$high$med ]] && lg_pass AUTH-001 "No source exceeded $threshold failed logins"

  # --- root targeting
  if (( root_fail >= threshold )); then
    lg_finding MEDIUM AUTH-004 "Repeated failed logins for root" \
      "$root_fail failed attempts targeted the root account." \
      "Set PermitRootLogin no and block offending sources." "root: $root_fail failed password attempts"
  else lg_pass AUTH-004 "No sustained attacks on the root account"; fi
  if [[ -n $root_pw ]]; then
    lg_finding HIGH AUTH-005 "Root logged in over SSH with a password" \
      "Direct password logins to root bypass accountability and are the top brute-force payoff." \
      "Disable root password login and verify the activity was legitimate." "$root_pw"
  else lg_pass AUTH-005 "No password-based root logins"; fi

  # --- username enumeration
  if (( invalid_total >= threshold )); then
    lg_finding MEDIUM AUTH-006 "Invalid-user probing (username enumeration)" \
      "$invalid_total attempts used usernames that do not exist - typical of automated scanners." \
      "Rate-limit with fail2ban; restrict logins with AllowUsers/AllowGroups." "$(_auth_top 10 <<<"$inv_lines")"
  else lg_pass AUTH-006 "No invalid-user probing at scale"; fi

  # --- privilege escalation failures
  if (( sudo_fail >= 5 )); then
    lg_finding MEDIUM AUTH-007 "Repeated sudo authentication failures" \
      "$sudo_fail sudo failures were logged; a local account may be compromised or misused." \
      "Review who ran sudo (grep sudo $src) and reset affected passwords." "sudo failures: $sudo_fail"
  elif (( sudo_fail > 0 )); then
    lg_finding LOW AUTH-007 "sudo authentication failures" \
      "$sudo_fail sudo failure(s) logged." "Confirm they were typos by the account owner." "sudo failures: $sudo_fail"
  else lg_pass AUTH-007 "No sudo authentication failures"; fi
  if (( su_fail >= 3 )); then
    lg_finding MEDIUM AUTH-008 "Repeated su failures" \
      "$su_fail failed 'su' attempts were logged." "Restrict su to the wheel group (pam_wheel) and review the source accounts." "su failures: $su_fail"
  elif (( su_fail > 0 )); then
    lg_finding LOW AUTH-008 "su authentication failures" "$su_fail failed 'su' attempt(s)." "Confirm they were legitimate." "su failures: $su_fail"
  else lg_pass AUTH-008 "No su authentication failures"; fi

  # --- account creation / break-in banners
  if [[ -n $new_users ]]; then
    lg_finding LOW AUTH-009 "User accounts created in the log window" \
      "New accounts are a common persistence technique." "Verify each account creation was authorised." "$new_users"
  else lg_pass AUTH-009 "No new accounts created in the log window"; fi
  if (( breakin > 0 )); then
    lg_finding HIGH AUTH-010 "SSH 'POSSIBLE BREAK-IN ATTEMPT' warnings" \
      "sshd flagged $breakin connection(s) whose reverse DNS does not match the forward lookup." \
      "Review the matching log lines and block the sources." "warnings: $breakin"
  else lg_pass AUTH-010 "No sshd break-in warnings"; fi
  return 0
}
