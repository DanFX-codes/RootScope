#!/usr/bin/env bash
# LinuxGuard module: network & listening-port inspection (NET-xxx)
# shellcheck shell=bash

audit_network() {
  lg_module_begin network "Network & Listening Port Inspection"
  if ! lg_runtime_available; then
    lg_note "Offline audit without a runtime snapshot (_cmd/) - listening-port and sysctl checks skipped."
    return 0
  fi
  _net_listeners
  _net_sysctl_checks
}

# _net_classify <proto> <port>  -> sets NET_SEV NET_SVC NET_WHY NET_FIX (SEV empty = acceptable)
_net_classify() {
  local proto=$1 port=$2
  NET_SEV="" NET_SVC="" NET_WHY="" NET_FIX=""
  case $port in
    23)   NET_SEV=CRITICAL NET_SVC=telnet NET_WHY="sends credentials and sessions in cleartext"
          NET_FIX="Disable telnet and use SSH." ;;
    2375) NET_SEV=CRITICAL NET_SVC="docker-api" NET_WHY="unauthenticated Docker API gives remote root on the host"
          NET_FIX="Bind Docker to its unix socket or require TLS client certificates (port 2376)." ;;
    21)   NET_SEV=HIGH NET_SVC=ftp NET_WHY="cleartext file transfer and credentials"
          NET_FIX="Replace with SFTP/FTPS; firewall the port if it must stay." ;;
    69)   NET_SEV=HIGH NET_SVC=tftp NET_WHY="unauthenticated file transfer"; NET_FIX="Disable TFTP or restrict to a management VLAN." ;;
    512|513) NET_SEV=HIGH NET_SVC="rexec/rlogin" NET_WHY="legacy r-services with weak trust model"
          NET_FIX="Remove the r-services and use SSH." ;;
    514)  if [[ $proto == udp ]]; then
            NET_SEV=MEDIUM NET_SVC=syslog NET_WHY="remote syslog accepts unauthenticated log injection"
            NET_FIX="Restrict to trusted log senders or use TLS syslog (6514)."
          else
            NET_SEV=HIGH NET_SVC=rsh NET_WHY="legacy remote shell"; NET_FIX="Remove rsh and use SSH."
          fi ;;
    135|139|445) NET_SEV=HIGH NET_SVC="smb/netbios" NET_WHY="frequent target of worms and credential attacks"
          NET_FIX="Firewall SMB from untrusted networks; disable SMBv1." ;;
    3389) NET_SEV=HIGH NET_SVC=rdp NET_WHY="heavily brute-forced remote desktop service"
          NET_FIX="Restrict to a VPN/bastion; enable NLA." ;;
    5900|5901|5902|5903) NET_SEV=HIGH NET_SVC=vnc NET_WHY="weakly authenticated remote desktop"
          NET_FIX="Tunnel VNC over SSH or a VPN; never expose it directly." ;;
    1433|1521|3306|5432|5984|6379|9042|9200|11211|27017)
          case $port in
            1433) NET_SVC="mssql" ;; 1521) NET_SVC="oracle" ;; 3306) NET_SVC="mysql/mariadb" ;;
            5432) NET_SVC="postgresql" ;; 5984) NET_SVC="couchdb" ;; 6379) NET_SVC="redis" ;;
            9042) NET_SVC="cassandra" ;; 9200) NET_SVC="elasticsearch" ;; 11211) NET_SVC="memcached" ;;
            27017) NET_SVC="mongodb" ;;
          esac
          NET_SEV=HIGH NET_WHY="database/cache service reachable from the network; often unauthenticated by default"
          NET_FIX="Bind to 127.0.0.1 or a private interface and firewall the port." ;;
    111)  NET_SEV=MEDIUM NET_SVC=rpcbind NET_WHY="RPC portmapper aids reconnaissance and amplification attacks"
          NET_FIX="Disable rpcbind unless NFS/NIS is required." ;;
    2049) NET_SEV=MEDIUM NET_SVC=nfs NET_WHY="NFS exports can leak data when exposed"; NET_FIX="Restrict NFS to trusted hosts." ;;
    161)  NET_SEV=MEDIUM NET_SVC=snmp NET_WHY="SNMP v1/v2c uses community strings in cleartext"
          NET_FIX="Use SNMPv3 and restrict by source address." ;;
    80|8080) NET_SEV=LOW NET_SVC=http NET_WHY="unencrypted web traffic"; NET_FIX="Redirect to HTTPS." ;;
    25)   NET_SEV=LOW NET_SVC=smtp NET_WHY="public mail transfer agent (relay/abuse risk)"
          NET_FIX="Ensure relaying is disabled and TLS is enforced." ;;
    22|443|53|123|67|68) : ;;   # expected services
    *)    NET_SEV=LOW NET_SVC="unclassified" NET_WHY="unreviewed network service"
          NET_FIX="Confirm the service is required; otherwise stop it or bind it to localhost." ;;
  esac
}

_net_listeners() {
  local out
  out=$(lg_run ss ss -tulnp)
  if [[ -z $out ]]; then
    lg_note "Could not enumerate listening sockets ('ss' unavailable or no permission)."
    return 0
  fi
  declare -A seen=()
  local proto state rq sq local_addr peer proc addr port pname public="" other="" nrisky=0 nlisten=0
  while read -r proto state rq sq local_addr peer proc; do
    [[ $proto == tcp* || $proto == udp* ]] || continue
    port=${local_addr##*:}; addr=${local_addr%:*}
    addr=${addr%%\%*}; addr=${addr#[}; addr=${addr%]}
    [[ $port =~ ^[0-9]+$ ]] || continue
    case $addr in 127.*|::1) public=no ;; *) public=yes ;; esac
    proto=${proto%%[0-9]*}                       # tcp6 -> tcp
    pname=""; [[ $proc =~ \"([^\"]+)\" ]] && pname=${BASH_REMATCH[1]}
    [[ -n ${seen["$proto/$port/$public"]:-} ]] && continue
    seen["$proto/$port/$public"]=1
    nlisten=$(( nlisten + 1 ))
    [[ $public == yes ]] || continue
    _net_classify "$proto" "$port"
    [[ -n $NET_SEV ]] || continue
    if [[ $NET_SVC == unclassified ]]; then
      other+="$proto/$port on $addr${pname:+ ($pname)}"$'\n'
    else
      nrisky=$(( nrisky + 1 ))
      lg_finding "$NET_SEV" NET-001 "Exposed $NET_SVC service on $proto/$port" \
        "${NET_SVC} is listening on $addr: $NET_WHY." "$NET_FIX" \
        "$proto  $addr:$port${pname:+  process=$pname}"
    fi
  done <<<"$out"
  if [[ -n $other ]]; then
    lg_finding LOW NET-002 "Unreviewed services listening on all/external interfaces" \
      "Each exposed listener enlarges the attack surface." \
      "Confirm each service is required; bind others to 127.0.0.1 or stop them." "$other"
  fi
  (( nrisky == 0 )) && [[ -z $other ]] && lg_pass NET-001 "No risky services exposed ($nlisten listener(s) reviewed)"
  return 0
}

_net_read_sysctl() {   # _net_read_sysctl net.ipv4.ip_forward
  local p="$LG_ROOT/proc/sys/${1//./\/}"
  [[ -r $p ]] && tr -d '[:space:]' < "$p"
}

_net_sysctl_checks() {
  local v
  v=$(_net_read_sysctl kernel.randomize_va_space)
  if [[ -n $v ]]; then
    if [[ $v != 2 ]]; then
      lg_finding MEDIUM NET-003 "ASLR is not fully enabled" \
        "kernel.randomize_va_space=$v (expected 2). Memory-corruption exploits become far easier." \
        "sysctl -w kernel.randomize_va_space=2 and persist it in /etc/sysctl.d/." "kernel.randomize_va_space = $v"
    else lg_pass NET-003 "ASLR fully enabled"; fi
  fi
  v=$(_net_read_sysctl net.ipv4.tcp_syncookies)
  if [[ -n $v ]]; then
    if [[ $v == 0 ]]; then
      lg_finding MEDIUM NET-004 "TCP SYN cookies disabled" \
        "The host is more vulnerable to SYN-flood denial of service." \
        "sysctl -w net.ipv4.tcp_syncookies=1" "net.ipv4.tcp_syncookies = 0"
    else lg_pass NET-004 "TCP SYN cookies enabled"; fi
  fi
  v=$(_net_read_sysctl net.ipv4.conf.all.accept_source_route)
  if [[ -n $v ]]; then
    if [[ $v != 0 ]]; then
      lg_finding MEDIUM NET-005 "Source-routed packets are accepted" \
        "Source routing lets an attacker dictate packet paths and spoof trusted hosts." \
        "sysctl -w net.ipv4.conf.all.accept_source_route=0" "net.ipv4.conf.all.accept_source_route = $v"
    else lg_pass NET-005 "Source routing rejected"; fi
  fi
  v=$(_net_read_sysctl net.ipv4.ip_forward)
  if [[ -n $v ]]; then
    if [[ $v == 1 ]]; then
      lg_finding LOW NET-006 "IPv4 forwarding is enabled" \
        "Expected on routers, VPN gateways and container hosts; unexpected elsewhere." \
        "sysctl -w net.ipv4.ip_forward=0 if this host is not a router." "net.ipv4.ip_forward = 1"
    else lg_pass NET-006 "IPv4 forwarding disabled"; fi
  fi
  return 0
}
