# LinuxGuard - authentication log analyser.
# POSIX awk (works with mawk, gawk and busybox awk).
# Input : syslog-style auth log lines (/var/log/auth.log, /var/log/secure, journalctl).
# Output: tab-separated records consumed by lib/authlog.sh.

function after(word,   i) {
  for (i = 1; i < NF; i++) if ($i == word) return $(i + 1)
  return ""
}
function user_for(   i) {
  for (i = 1; i < NF; i++)
    if ($i == "for") {
      if ($(i + 1) == "invalid" && $(i + 2) == "user") return $(i + 3)
      return $(i + 1)
    }
  return ""
}

/sshd(\[[0-9]+\])?: Failed (password|keyboard-interactive\/pam|none) for/ {
  ip = after("from"); user = user_for()
  total_fail++
  if (ip != "") fail_ip[ip]++
  if (user == "root") root_fail++
  next
}
/sshd(\[[0-9]+\])?: Invalid user / {
  name = after("user"); invalid_total++
  if (name != "") invalid_user[name]++
  next
}
/sshd(\[[0-9]+\])?: Accepted / {
  method = after("Accepted"); user = user_for(); ip = after("from")
  if (user == "") user = "-"
  if (ip == "") ip = "-"
  if (method == "") method = "-"
  acc[user "\t" ip "\t" method]++
  next
}
/sudo(\[[0-9]+\])?:.*(incorrect password attempts|authentication failure)/ { sudo_fail++; next }
/ su(-l)?(\[[0-9]+\])?: (FAILED SU|.*authentication failure)/ { su_fail++; next }
/useradd(\[[0-9]+\])?: new user:/ {
  if (match($0, /name=[^,]+/)) new_user[substr($0, RSTART + 5, RLENGTH - 5)] = 1
  next
}
/POSSIBLE BREAK-IN ATTEMPT/ { breakin++ }

END {
  printf "TOTAL_FAIL\t%d\n", total_fail
  printf "ROOT_FAIL\t%d\n", root_fail
  printf "INVALID_TOTAL\t%d\n", invalid_total
  printf "SUDO_FAIL\t%d\n", sudo_fail
  printf "SU_FAIL\t%d\n", su_fail
  printf "BREAKIN\t%d\n", breakin
  for (k in fail_ip)      printf "FAIL_IP\t%s\t%d\n", k, fail_ip[k]
  for (k in invalid_user) printf "INVALID_USER\t%s\t%d\n", k, invalid_user[k]
  for (k in new_user)     printf "NEW_USER\t%s\n", k
  for (k in acc) { split(k, p, "\t"); printf "ACCEPT\t%s\t%s\t%s\t%d\n", p[1], p[2], p[3], acc[k] }
}
