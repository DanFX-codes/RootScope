#!/usr/bin/env bash
# LinuxGuard module: SSH security auditing (SSH-xxx)
# shellcheck shell=bash

declare -gA SSHC=()   # effective sshd settings: lowercase keyword -> value (first match wins)

# _ssh_parse_file <file> [depth]  - parse sshd_config honouring Include; stops at Match.
_ssh_parse_file() {
  local f=$1 depth=${2:-0} line key val pat inc
  [[ -r $f ]] || return 0
  (( depth > 5 )) && return 0
  while IFS= read -r line || [[ -n $line ]]; do
    line=${line%%#*}
    line=${line#"${line%%[![:space:]]*}"}
    [[ -n $line ]] || continue
    key=${line%%[[:space:]=]*}
    val=${line#"$key"}
    val=${val#"${val%%[![:space:]=]*}"}
    val=${val%"${val##*[![:space:]]}"}
    key=${key,,}
    case $key in
      match) break ;;
      include)
        local -a pats=()
        read -ra pats <<<"$val"
        for pat in "${pats[@]}"; do
          [[ $pat == /* ]] || pat="/etc/ssh/$pat"
          local oldnull; oldnull=$(shopt -p nullglob); shopt -s nullglob
          # shellcheck disable=SC2231
          for inc in "$LG_ROOT"$pat; do _ssh_parse_file "$inc" $(( depth + 1 )); done
          eval "$oldnull"
        done ;;
      *) [[ -z ${SSHC[$key]+x} ]] && SSHC[$key]=$val ;;
    esac
  done < "$f"
}

# Value of a keyword, or the OpenSSH default when unset.
_ssh_get() { local v=${SSHC[$1]-}; [[ -n $v ]] || v=$2; printf '%s' "${v,,}"; }

_ssh_seconds() {   # 2m -> 120, 30 -> 30
  local v=$1
  case $v in
    *m) printf '%d' $(( ${v%m} * 60 )) ;;
    *s) printf '%d' "${v%s}" ;;
    *)  [[ $v =~ ^[0-9]+$ ]] && printf '%d' "$v" || printf '120' ;;
  esac
}

audit_ssh() {
  lg_module_begin ssh "SSH Security Auditing"
  local cfg="$LG_ROOT/etc/ssh/sshd_config" k src="sshd_config" line out
  SSHC=()
  if [[ ! -r $cfg ]]; then
    lg_note "No readable /etc/ssh/sshd_config - SSH daemon checks skipped (sshd not installed?)."
    _ssh_key_files
    return 0
  fi
  if lg_runtime_available && out=$(lg_run sshd_T sshd -T) && [[ -n $out ]]; then
    while read -r k line; do [[ -n $k ]] && SSHC[$k]=$line; done <<<"$out"
    src="sshd -T (effective configuration)"
  else
    _ssh_parse_file "$cfg"
    src="/etc/ssh/sshd_config (parsed; Match blocks ignored)"
  fi
  lg_info "SSH configuration source: $src"
  _ssh_daemon_checks
  _ssh_key_files
}

_ssh_daemon_checks() {
  local v w
  # --- root login
  v=$(_ssh_get permitrootlogin prohibit-password)
  case $v in
    yes) lg_finding CRITICAL SSH-001 "SSH permits direct root login with a password" \
           "PermitRootLogin yes exposes the most targeted account to online password guessing." \
           "Set 'PermitRootLogin no' (or prohibit-password) and use sudo from a named account." "PermitRootLogin $v" ;;
    no)  lg_pass SSH-001 "Root login over SSH is disabled" ;;
    *)   lg_finding LOW SSH-001 "Root SSH login allowed with keys only ($v)" \
           "Key-only root login is safer than passwords but still bypasses per-user accountability." \
           "Prefer 'PermitRootLogin no' and escalate with sudo." "PermitRootLogin $v" ;;
  esac
  # --- empty passwords
  v=$(_ssh_get permitemptypasswords no)
  if [[ $v == yes ]]; then
    lg_finding CRITICAL SSH-002 "SSH allows empty passwords" \
      "Accounts with blank passwords can log in over the network." \
      "Set 'PermitEmptyPasswords no'." "PermitEmptyPasswords yes"
  else lg_pass SSH-002 "Empty passwords rejected"; fi
  # --- password auth
  v=$(_ssh_get passwordauthentication yes)
  if [[ $v == yes ]]; then
    lg_finding MEDIUM SSH-003 "SSH password authentication enabled" \
      "Passwords are exposed to brute-force and credential stuffing; public keys are far stronger." \
      "Deploy public keys, then set 'PasswordAuthentication no' (and 'KbdInteractiveAuthentication no')." "PasswordAuthentication $v"
  else lg_pass SSH-003 "Password authentication disabled (keys only)"; fi
  # --- legacy protocol
  v=$(_ssh_get protocol 2)
  if [[ $v == *1* ]]; then
    lg_finding CRITICAL SSH-004 "SSH protocol version 1 enabled" \
      "Protocol 1 has known cryptographic flaws (session hijacking, MITM)." "Remove the Protocol directive or set 'Protocol 2'." "Protocol $v"
  fi
  # --- host-based auth / user env
  v=$(_ssh_get hostbasedauthentication no); w=$(_ssh_get permituserenvironment no)
  if [[ $v == yes || $w == yes ]]; then
    lg_finding HIGH SSH-005 "Trust-based SSH features enabled" \
      "HostbasedAuthentication and PermitUserEnvironment weaken authentication and can bypass restrictions." \
      "Set both to 'no'." "HostbasedAuthentication $v"$'\n'"PermitUserEnvironment $w"
  else lg_pass SSH-005 "Host-based auth and user environment processing disabled"; fi
  # --- retries
  v=$(_ssh_get maxauthtries 6)
  if [[ $v =~ ^[0-9]+$ ]] && (( v > 6 )); then
    lg_finding MEDIUM SSH-006 "High MaxAuthTries ($v)" \
      "Many attempts per connection make online guessing cheaper." "Set 'MaxAuthTries 3' or 4." "MaxAuthTries $v"
  elif [[ $v =~ ^[0-9]+$ ]] && (( v > 4 )); then
    lg_finding LOW SSH-006 "MaxAuthTries above recommended value ($v)" \
      "CIS recommends 4 or fewer authentication attempts per connection." "Set 'MaxAuthTries 3' or 4." "MaxAuthTries $v"
  else lg_pass SSH-006 "MaxAuthTries is $v"; fi
  # --- X11
  v=$(_ssh_get x11forwarding no)
  if [[ $v == yes ]]; then
    lg_finding LOW SSH-007 "X11 forwarding enabled" \
      "X11 forwarding exposes the client's display to the server." "Set 'X11Forwarding no' unless needed." "X11Forwarding yes"
  else lg_pass SSH-007 "X11 forwarding disabled"; fi
  # --- weak crypto (only when explicitly configured; defaults are modern)
  local weak=""
  [[ ${SSHC[ciphers]-} =~ (3des|arcfour|blowfish|cast128|-cbc) ]] && weak+="Ciphers ${SSHC[ciphers]}"$'\n'
  [[ ${SSHC[macs]-} =~ (hmac-md5|hmac-sha1-96|umac-64|hmac-ripemd) ]] && weak+="MACs ${SSHC[macs]}"$'\n'
  [[ ${SSHC[kexalgorithms]-} =~ (group1-sha1|group-exchange-sha1|group14-sha1) ]] && weak+="KexAlgorithms ${SSHC[kexalgorithms]}"$'\n'
  if [[ -n $weak ]]; then
    lg_finding HIGH SSH-008 "Weak SSH ciphers, MACs or key exchange configured" \
      "CBC ciphers, MD5/SHA-1 MACs and legacy DH groups are vulnerable to known attacks." \
      "Remove the weak algorithms or delete the directive to use OpenSSH's secure defaults." "$weak"
  else lg_pass SSH-008 "No weak cryptographic algorithms explicitly configured"; fi
  # --- login grace time
  v=$(_ssh_get logingracetime 2m); v=$(_ssh_seconds "$v")
  if (( v == 0 )); then
    lg_finding MEDIUM SSH-009 "No login grace time limit" \
      "LoginGraceTime 0 lets unauthenticated connections stay open indefinitely (resource exhaustion)." \
      "Set 'LoginGraceTime 30'." "LoginGraceTime 0"
  elif (( v > 120 )); then
    lg_finding LOW SSH-009 "Long login grace time (${v}s)" \
      "Slow, unauthenticated connections tie up sshd slots." "Set 'LoginGraceTime 30'." "LoginGraceTime ${v}s"
  else lg_pass SSH-009 "Login grace time is ${v}s"; fi
  # --- allow lists
  if [[ -z ${SSHC[allowusers]-} && -z ${SSHC[allowgroups]-} ]]; then
    lg_finding LOW SSH-010 "No AllowUsers/AllowGroups restriction" \
      "Any valid local account may attempt SSH login." \
      "Add 'AllowGroups ssh-users' (or AllowUsers) to limit who may connect." "AllowUsers/AllowGroups not set"
  else lg_pass SSH-010 "SSH access is restricted with an allow-list"; fi
}

_ssh_key_files() {
  local d f mode ak_bad="" key_bad="" root_keys="" rel
  for d in "$LG_ROOT"/home/*/.ssh "$LG_ROOT/root/.ssh"; do
    [[ -d $d ]] || continue
    f="$d/authorized_keys"
    if [[ -f $f ]]; then
      mode=$(lg_mode "$f"); rel=$(lg_strip_root "$f")
      lg_mode_has "$mode" 022 && ak_bad+="$rel  mode=$mode"$'\n'
      [[ $d == "$LG_ROOT/root/.ssh" && -s $f ]] && root_keys+="$rel"$'\n'
    fi
    for f in "$d"/*; do
      [[ -f $f && $f != *.pub && $f != */authorized_keys && $f != */known_hosts* && $f != */config ]] || continue
      [[ $(stat -c %s "$f" 2>/dev/null || echo 99999) -lt 20000 ]] || continue
      grep -qs 'PRIVATE KEY' "$f" || continue
      mode=$(lg_mode "$f")
      lg_mode_exceeds "$mode" 600 && key_bad+="$(lg_strip_root "$f")  mode=$mode"$'\n'
    done
  done
  if [[ -n $key_bad ]]; then
    lg_finding HIGH SSH-011 "SSH private keys readable by other users" \
      "Anyone who can read a private key can impersonate its owner (OpenSSH also refuses such keys)." \
      "chmod 600 <key>; consider the key compromised if the host is shared." "$key_bad"
  else lg_pass SSH-011 "SSH private keys have safe permissions"; fi
  if [[ -n $ak_bad ]]; then
    lg_finding HIGH SSH-012 "authorized_keys writable by group/others" \
      "Others can add their own public key and gain access as that user." "chmod 600 <file>" "$ak_bad"
  else lg_pass SSH-012 "authorized_keys files are not group/world-writable"; fi
  if [[ -n $root_keys ]]; then
    lg_finding MEDIUM SSH-013 "Root has authorized SSH keys" \
      "Keys in /root/.ssh/authorized_keys allow direct root access that bypasses sudo logging." \
      "Remove unneeded keys; prefer named accounts plus sudo." "$root_keys"
  else lg_pass SSH-013 "No SSH keys authorised for root"; fi
  return 0
}
