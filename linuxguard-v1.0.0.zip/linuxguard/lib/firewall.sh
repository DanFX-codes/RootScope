#!/usr/bin/env bash
# LinuxGuard module: firewall & service auditing (FWS-xxx)
# shellcheck shell=bash

audit_firewall() {
  lg_module_begin firewall "Firewall & Service Auditing"
  if ! lg_runtime_available; then
    lg_note "Offline audit without a runtime snapshot (_cmd/) - firewall and service checks skipped."
    return 0
  fi
  _fw_status
  _fw_services
}

_fw_status() {
  local out active=() weak="" seen_output=0 pol

  # --- ufw
  if out=$(lg_run ufw ufw status verbose) && [[ -n $out ]]; then
    seen_output=1
    if grep -qi '^Status: active' <<<"$out"; then
      pol=$(sed -n 's/^Default: *\([a-z]*\) (incoming).*/\1/p' <<<"$out" | head -n1)
      if [[ -n $pol && $pol != deny && $pol != reject ]]; then
        weak+="ufw: default incoming policy is '$pol'"$'\n'
      fi
      active+=(ufw)
    fi
  fi
  # --- firewalld
  if out=$(lg_run firewall_cmd firewall-cmd --state) && [[ -n $out ]]; then
    seen_output=1
    [[ $out == running* ]] && active+=(firewalld)
  fi
  # --- nftables
  if out=$(lg_run nft nft list ruleset) && [[ -n $out ]]; then
    seen_output=1
    if grep -q 'hook input' <<<"$out"; then
      if grep -qE 'hook input.*policy (drop|reject)' <<<"$out" || grep -qE '^\s*(.*\s)?(drop|reject)\b' <<<"$out"; then
        active+=(nftables)
      else
        weak+="nftables: input chain accepts everything (policy accept, no drop/reject rules)"$'\n'
      fi
    fi
  fi
  # --- iptables
  if out=$(lg_run iptables iptables -S) && [[ -n $out ]]; then
    seen_output=1
    if grep -qE '^-P INPUT (DROP|REJECT)' <<<"$out" || grep -qE '^-A INPUT .*-j (DROP|REJECT)' <<<"$out"; then
      active+=(iptables)
    elif grep -q '^-P INPUT ACCEPT' <<<"$out"; then
      weak+="iptables: INPUT policy is ACCEPT with no DROP/REJECT rules"$'\n'
    fi
  fi

  if (( ${#active[@]} )); then
    lg_pass FWS-001 "Host firewall active (${active[*]})"
    if [[ -n $weak ]]; then
      lg_finding MEDIUM FWS-002 "Firewall default input policy is permissive" \
        "A default-allow inbound policy only blocks what is explicitly listed - everything else is exposed." \
        "Set the default incoming policy to deny/drop and allow only required ports." "$weak"
    else
      lg_pass FWS-002 "Default inbound policy is restrictive"
    fi
  elif (( ! seen_output )) && ! lg_is_privileged; then
    lg_note "Firewall state needs root (ufw/nft/iptables returned nothing) - firewall check skipped."
  else
    lg_finding HIGH FWS-001 "No active host firewall detected" \
      "No ufw, firewalld, nftables or iptables ruleset restricts inbound traffic." \
      "Enable one: 'ufw default deny incoming && ufw allow OpenSSH && ufw enable' or 'systemctl enable --now firewalld'." \
      "${weak:-no active ruleset found}"
  fi
}

# _fw_service_risk <service-name>  -> sets SVC_SEV SVC_WHY
_fw_service_risk() {
  SVC_SEV="" SVC_WHY=""
  case $1 in
    telnet*|inetutils-telnetd) SVC_SEV=CRITICAL SVC_WHY="Telnet transmits credentials in cleartext." ;;
    rsh*|rlogin*|rexec*|rsh-server) SVC_SEV=HIGH SVC_WHY="Legacy r-services trust the network and send data unencrypted." ;;
    tftp*|atftpd) SVC_SEV=HIGH SVC_WHY="TFTP has no authentication." ;;
    vsftpd|proftpd|pure-ftpd|ftpd) SVC_SEV=MEDIUM SVC_WHY="FTP sends credentials in cleartext." ;;
    xinetd|inetd|openbsd-inetd) SVC_SEV=MEDIUM SVC_WHY="Super-servers frequently enable forgotten legacy daemons." ;;
    ypbind|ypserv|nis) SVC_SEV=MEDIUM SVC_WHY="NIS exposes password maps and is trivially spoofed." ;;
    rpcbind|portmap) SVC_SEV=MEDIUM SVC_WHY="RPC portmapper aids reconnaissance; only needed for NFS/NIS." ;;
    nfs-server|nfs-kernel-server) SVC_SEV=MEDIUM SVC_WHY="NFS should be restricted to trusted hosts." ;;
    smbd|nmbd|samba) SVC_SEV=MEDIUM SVC_WHY="Samba widens the attack surface; run only on file servers." ;;
    snmpd) SVC_SEV=MEDIUM SVC_WHY="SNMP v1/v2c leaks data and uses weak community strings." ;;
    avahi-daemon|cups|cups-browsed|bluetooth) SVC_SEV=LOW SVC_WHY="Desktop-oriented service that is rarely needed on servers." ;;
  esac
}

_fw_services() {
  local out unit name sev_ev="" any_risky=0 running=""
  out=$(lg_run systemctl_running systemctl list-units --type=service --state=running --no-legend --plain)
  if [[ -z $out ]]; then
    lg_note "Could not list running services (systemd unavailable) - service checks skipped."
    return 0
  fi
  while read -r unit _; do
    [[ -n $unit ]] || continue
    name=${unit%.service}; name=${name%.socket}
    running+=" $name "
    _fw_service_risk "$name"
    if [[ -n $SVC_SEV ]]; then
      any_risky=1
      lg_finding "$SVC_SEV" FWS-003 "Risky service running: $name" "$SVC_WHY" \
        "systemctl disable --now $name  (or remove the package if unused)." "$unit"
    fi
  done <<<"$out"
  (( any_risky )) || lg_pass FWS-003 "No legacy or high-risk services running"

  if [[ $running =~ \ (fail2ban|sshguard|crowdsec)\  ]]; then
    lg_pass FWS-004 "Brute-force protection service running"
  else
    lg_finding LOW FWS-004 "No brute-force protection service running" \
      "Nothing automatically blocks hosts that repeatedly fail authentication." \
      "Install and enable fail2ban, sshguard or crowdsec." "fail2ban/sshguard/crowdsec not running"
  fi
  if [[ $running =~ \ (auditd|auditd\.service)\  ]]; then
    lg_pass FWS-005 "Audit daemon running"
  else
    lg_finding LOW FWS-005 "Linux audit daemon (auditd) not running" \
      "Without auditd there is no kernel-level record of security-relevant events." \
      "Install and enable auditd (apt install auditd / dnf install audit)." "auditd not running"
  fi
  return 0
}
