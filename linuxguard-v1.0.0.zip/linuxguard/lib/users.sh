#!/usr/bin/env bash
# LinuxGuard module: user & privilege auditing (USR-xxx)
# shellcheck shell=bash

audit_users() {
  lg_module_begin users "User & Privilege Auditing"
  local passwd="$LG_ROOT/etc/passwd"
  if [[ ! -r $passwd ]]; then
    lg_note "Cannot read /etc/passwd - user checks skipped."
    return 0
  fi
  _users_uid0 "$passwd"
  _users_dupes "$passwd"
  _users_system_shells "$passwd"
  _users_shadow "$LG_ROOT/etc/shadow"
  _users_sudoers
  _users_privileged_groups "$LG_ROOT/etc/group"
  _users_password_policy "$LG_ROOT/etc/login.defs"
}

_users_uid0() {
  local name uid ev=""
  while IFS=: read -r name _ uid _; do
    [[ -z $name || $name == \#* ]] && continue
    [[ $uid =~ ^[0-9]+$ ]] || continue
    if (( 10#$uid == 0 )) && [[ $name != root ]]; then ev+="$name (uid 0)"$'\n'; fi
  done < "$1"
  if [[ -n $ev ]]; then
    lg_finding CRITICAL USR-001 "Non-root account with UID 0" \
      "Accounts with UID 0 have full root privileges. Only 'root' should have it." \
      "Remove or renumber the account (userdel / usermod -u), then investigate how it was created." "$ev"
  else
    lg_pass USR-001 "Only root has UID 0"
  fi
}

_users_dupes() {
  local d
  d=$(awk -F: '$1 !~ /^#/ && $3 ~ /^[0-9]+$/ { n[$3]++; u[$3] = u[$3] (u[$3] == "" ? "" : ",") $1 }
               END { for (k in n) if (n[k] > 1) printf "UID %s shared by: %s\n", k, u[k] }' "$1" | sort)
  if [[ -n $d ]]; then
    lg_finding MEDIUM USR-002 "Duplicate UIDs in /etc/passwd" \
      "Accounts that share a UID share all file ownership and privileges, defeating accountability." \
      "Assign each account a unique UID (usermod -u) and fix file ownership (find / -uid OLD -exec chown NEW {} +)." "$d"
  else
    lg_pass USR-002 "No duplicate UIDs"
  fi
}

_users_system_shells() {
  local name uid shell ev=""
  while IFS=: read -r name _ uid _ _ _ shell; do
    [[ -z $name || $name == \#* ]] && continue
    [[ $uid =~ ^[0-9]+$ ]] || continue
    (( 10#$uid >= 1 && 10#$uid < 1000 )) || continue
    case ${shell##*/} in nologin|false|sync|shutdown|halt|git-shell) continue ;; esac
    ev+="$name (uid $uid) -> ${shell:-/bin/sh}"$'\n'
  done < "$1"
  if [[ -n $ev ]]; then
    lg_finding MEDIUM USR-003 "System accounts with an interactive login shell" \
      "Service accounts (UID < 1000) should not be able to log in interactively." \
      "Set the shell to /usr/sbin/nologin: usermod -s /usr/sbin/nologin <account>." "$ev"
  else
    lg_pass USR-003 "System accounts have non-interactive shells"
  fi
}

_users_shadow() {
  local shadow=$1 empty weak
  if [[ ! -r $shadow ]]; then
    lg_note "Cannot read /etc/shadow (run as root) - password-hash checks skipped."
    return 0
  fi
  empty=$(awk -F: '$1 !~ /^#/ && NF >= 2 && $2 == "" { print $1 }' "$shadow")
  if [[ -n $empty ]]; then
    lg_finding CRITICAL USR-004 "Accounts with an empty password" \
      "An empty password field allows login without a password (where PAM/SSH permit it)." \
      "Lock or set a password immediately: passwd -l <account> or passwd <account>." "$empty"
  else
    lg_pass USR-004 "No accounts have an empty password"
  fi
  weak=$(awk -F: '$1 !~ /^#/ { if ($2 ~ /^\$1\$/) print $1 " (MD5-crypt)";
                    else if ($2 != "" && $2 !~ /^[!*]/ && $2 !~ /^\$/) print $1 " (legacy DES crypt)" }' "$shadow")
  if [[ -n $weak ]]; then
    lg_finding MEDIUM USR-005 "Weak password hashing algorithm in use" \
      "MD5-crypt and DES-crypt hashes are trivially crackable with modern hardware." \
      "Set ENCRYPT_METHOD to YESCRYPT/SHA512 in /etc/login.defs and force a password change for affected users." "$weak"
  else
    lg_pass USR-005 "Password hashes use modern algorithms"
  fi
}

_users_sudoers() {
  local files=() f all cmd noauth
  [[ -r $LG_ROOT/etc/sudoers ]] && files+=("$LG_ROOT/etc/sudoers")
  for f in "$LG_ROOT"/etc/sudoers.d/*; do [[ -f $f && -r $f ]] && files+=("$f"); done
  if (( ${#files[@]} == 0 )); then
    lg_note "Cannot read sudoers files (run as root) - sudo checks skipped."
    return 0
  fi
  all=$(grep -HE '^[^#]*NOPASSWD:[[:space:]]*ALL([[:space:]]|$)' "${files[@]}" 2>/dev/null)
  cmd=$(grep -HE '^[^#]*NOPASSWD:' "${files[@]}" 2>/dev/null | grep -vE 'NOPASSWD:[[:space:]]*ALL([[:space:]]|$)')
  noauth=$(grep -HE '^[[:space:]]*Defaults.*!authenticate' "${files[@]}" 2>/dev/null)
  all=$(lg_strip_root "$all"); cmd=$(lg_strip_root "$cmd"); noauth=$(lg_strip_root "$noauth")
  if [[ -n $all || -n $noauth ]]; then
    lg_finding HIGH USR-006 "Passwordless sudo for ALL commands" \
      "NOPASSWD: ALL (or !authenticate) turns any compromise of that account into instant root." \
      "Remove NOPASSWD/!authenticate (use visudo) or restrict to specific, non-shell commands." "$all"$'\n'"$noauth"
  elif [[ -n $cmd ]]; then
    lg_finding MEDIUM USR-006 "Passwordless sudo for specific commands" \
      "NOPASSWD rules are risky when the permitted command can spawn a shell or edit files." \
      "Review each rule; drop NOPASSWD where automation does not require it." "$cmd"
  else
    lg_pass USR-006 "No passwordless sudo rules"
  fi
}

_users_privileged_groups() {
  local ev total
  [[ -r $1 ]] || return 0
  ev=$(awk -F: '$1 ~ /^(sudo|wheel|admin)$/ && $4 != "" { print $1 ": " $4 }' "$1")
  total=$(awk -F: '$1 ~ /^(sudo|wheel|admin)$/ && $4 != "" { n = split($4, a, ","); for (i = 1; i <= n; i++) s[a[i]] = 1 }
                   END { c = 0; for (k in s) c++; print c + 0 }' "$1")
  if (( total > 3 )); then
    lg_finding LOW USR-007 "Large number of administrators ($total)" \
      "Every sudo-capable account is a path to root; keep the set small (least privilege)." \
      "Remove users that do not need administrative access from the sudo/wheel/admin group." "$ev"
  else
    lg_pass USR-007 "Administrator group is small ($total member(s))"
  fi
}

_users_password_policy() {
  local max
  max=$(awk '$1 == "PASS_MAX_DAYS" { print $2; exit }' "$1" 2>/dev/null)
  if [[ -z $max ]]; then
    lg_note "PASS_MAX_DAYS not found in /etc/login.defs - password-aging check skipped."
  elif [[ $max =~ ^[0-9]+$ ]] && (( max > 365 )); then
    lg_finding LOW USR-008 "Passwords never (or rarely) expire" \
      "PASS_MAX_DAYS is $max. Long-lived passwords extend the usefulness of any leaked credential." \
      "Set PASS_MAX_DAYS to 365 or less in /etc/login.defs (and chage -M for existing users)." "PASS_MAX_DAYS $max"
  else
    lg_pass USR-008 "Password maximum age is $max days"
  fi
}
