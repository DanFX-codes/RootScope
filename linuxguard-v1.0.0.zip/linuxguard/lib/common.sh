#!/usr/bin/env bash
# LinuxGuard - shared library: logging, finding registry, scoring, FS helpers.
# shellcheck shell=bash

LG_VERSION="1.0.0"

LG_FS=$'\037'   # field separator inside stored records
LG_NL=$'\036'   # newline placeholder inside stored evidence

LG_SEVERITIES=(CRITICAL HIGH MEDIUM LOW)
declare -gA LG_WEIGHT=([CRITICAL]=25 [HIGH]=10 [MEDIUM]=4 [LOW]=1)
declare -gA LG_RANK=([CRITICAL]=4 [HIGH]=3 [MEDIUM]=2 [LOW]=1)
declare -gA LG_COUNT=([CRITICAL]=0 [HIGH]=0 [MEDIUM]=0 [LOW]=0)
declare -gA LG_MOD_TITLE=()
declare -gA LG_MOD_PASS=()
declare -gA LG_MOD_COUNT=()          # "<module>:<SEVERITY>" -> n
LG_MODULE_ORDER=()
LG_FINDINGS=()                       # sev FS module FS id FS title FS detail FS fix FS evidence
LG_PASSED=()                         # module FS id FS title
LG_NOTES=()                          # module FS text
LG_MODULE=""
LG_PASS_TOTAL=0
LG_QUIET="${LG_QUIET:-0}"

# Audit root. Empty string = the live system. A non-empty value means "offline
# mode": every file read is prefixed with it, and runtime command output is
# read from "$LG_ROOT/_cmd/<name>" instead of executing anything.
LG_ROOT="${LG_ROOT:-}"
LG_ROOT="${LG_ROOT%/}"

# ---------------------------------------------------------------- logging ---
C_RED="" C_YEL="" C_BLU="" C_GRN="" C_DIM="" C_BLD="" C_RST=""
lg_color_init() {
  if [[ -t 2 && -z ${NO_COLOR:-} && ${LG_NO_COLOR:-0} != 1 ]]; then
    C_RED=$'\033[31m' C_YEL=$'\033[33m' C_BLU=$'\033[34m' C_GRN=$'\033[32m'
    C_DIM=$'\033[2m' C_BLD=$'\033[1m' C_RST=$'\033[0m'
  fi
}
lg_info() { (( LG_QUIET )) || printf '%s\n' "${C_BLU}[*]${C_RST} $*" >&2; return 0; }
lg_warn() { printf '%s\n' "${C_YEL}[!]${C_RST} $*" >&2; }
lg_err()  { printf '%s\n' "${C_RED}[x]${C_RST} $*" >&2; }

# ------------------------------------------------------ environment access ---
# True when privileged data (shadow, firewall state, ...) is expected to be readable.
lg_is_privileged() { [[ -n $LG_ROOT ]] || (( EUID == 0 )); }

# True when runtime state (ports, firewall, services, sysctl) can be inspected.
lg_runtime_available() { [[ -z $LG_ROOT ]] || [[ -d $LG_ROOT/_cmd ]]; }

# lg_run <fixture-name> <command> [args...]
# Live: run the command quietly. Offline: print "$LG_ROOT/_cmd/<fixture-name>".
lg_run() {
  local name=$1; shift
  if [[ -n $LG_ROOT ]]; then
    [[ -f $LG_ROOT/_cmd/$name ]] && cat "$LG_ROOT/_cmd/$name"
    return
  fi
  command -v "$1" >/dev/null 2>&1 || return 127
  "$@" 2>/dev/null
}

# Remove the audit-root prefix from text (paths in evidence stay clean).
lg_strip_root() { local s=$1; [[ -n $LG_ROOT ]] && s=${s//"$LG_ROOT"/}; printf '%s' "$s"; }

lg_mode()  { stat -c '%a' "$1" 2>/dev/null; }
lg_owner() { stat -c '%U' "$1" 2>/dev/null; }

# lg_mode_has <octal-mode> <octal-mask>  -> true if any mask bit is set
lg_mode_has() { (( (8#$1 & 8#$2) != 0 )); }
# lg_mode_exceeds <mode> <max-mode> -> true if mode grants bits outside max
lg_mode_exceeds() { (( (8#$1 & 8#7777 & ~8#$2) != 0 )); }

# -------------------------------------------------------- finding registry ---
lg_module_begin() {
  LG_MODULE=$1
  LG_MOD_TITLE[$1]=$2
  LG_MOD_PASS[$1]=0
  LG_MODULE_ORDER+=("$1")
  lg_info "Auditing: $2"
}

# lg_finding <SEVERITY> <ID> <title> <description> <remediation> [evidence]
lg_finding() {
  local sev=$1 id=$2 title=$3 detail=$4 fix=$5 evidence=${6:-}
  if [[ -z ${LG_RANK[$sev]:-} ]]; then
    lg_warn "internal error: invalid severity '$sev' for $id"
    return 1
  fi
  evidence=${evidence%$'\n'}
  evidence=${evidence//$'\n'/$LG_NL}
  detail=${detail//$'\n'/ }
  LG_FINDINGS+=("${sev}${LG_FS}${LG_MODULE}${LG_FS}${id}${LG_FS}${title}${LG_FS}${detail}${LG_FS}${fix}${LG_FS}${evidence}")
  LG_COUNT[$sev]=$(( LG_COUNT[$sev] + 1 ))
  LG_MOD_COUNT["$LG_MODULE:$sev"]=$(( ${LG_MOD_COUNT["$LG_MODULE:$sev"]:-0} + 1 ))
}

# lg_pass <ID> <title>
lg_pass() {
  LG_PASSED+=("${LG_MODULE}${LG_FS}$1${LG_FS}$2")
  LG_PASS_TOTAL=$(( LG_PASS_TOTAL + 1 ))
  LG_MOD_PASS[$LG_MODULE]=$(( ${LG_MOD_PASS[$LG_MODULE]:-0} + 1 ))
}

# lg_note <text>  - a limitation / skipped check, shown in the report.
lg_note() {
  LG_NOTES+=("${LG_MODULE}${LG_FS}$1")
  lg_info "note: $1"
}

# ----------------------------------------------------------------- scoring ---
lg_total_findings() {
  local sev t=0
  for sev in "${LG_SEVERITIES[@]}"; do t=$(( t + LG_COUNT[$sev] )); done
  printf '%d' "$t"
}

# 100 minus weighted findings, floored at 0.
lg_score() {
  local s=100 sev
  for sev in "${LG_SEVERITIES[@]}"; do s=$(( s - LG_COUNT[$sev] * LG_WEIGHT[$sev] )); done
  (( s < 0 )) && s=0
  printf '%d' "$s"
}

# Highest severity present (LOW when the system is clean).
lg_overall() {
  local sev
  for sev in "${LG_SEVERITIES[@]}"; do
    if (( LG_COUNT[$sev] > 0 )); then printf '%s' "$sev"; return; fi
  done
  printf 'LOW'
}

# lg_any_at_least <SEVERITY> -> true if any finding is at/above that severity
lg_any_at_least() {
  local want=$1 sev
  for sev in "${LG_SEVERITIES[@]}"; do
    (( LG_RANK[$sev] >= LG_RANK[$want] && LG_COUNT[$sev] > 0 )) && return 0
  done
  return 1
}
