#!/usr/bin/env bash
# LinuxGuard module: file permission auditing (PRM-xxx)
# shellcheck shell=bash

audit_perms() {
  lg_module_begin perms "File Permission Auditing"
  _perms_critical_files
  _perms_world_writable
  _perms_suid_sgid
  _perms_sticky
  _perms_home_dirs
}

# Directories worth scanning (existing ones only).
_perms_dirs() {
  local d
  for d in "$@"; do [[ -d $LG_ROOT$d ]] && printf '%s\n' "$LG_ROOT$d"; done
}

_perms_critical_files() {
  local entry p max sens f mode owner sev bad=0
  # path:max-allowed-mode:sensitive(yes = must not be world-readable)
  local entries=(
    "/etc/passwd:644:no" "/etc/group:644:no" "/etc/shadow:640:yes"
    "/etc/gshadow:640:yes" "/etc/sudoers:440:yes" "/etc/security/opasswd:600:yes"
    "/etc/ssh/sshd_config:644:no" "/etc/crontab:644:no"
  )
  for entry in "${entries[@]}"; do
    IFS=: read -r p max sens <<<"$entry"
    f="$LG_ROOT$p"
    [[ -f $f ]] || continue
    mode=$(lg_mode "$f"); [[ -n $mode ]] || continue
    if lg_mode_exceeds "$mode" "$max"; then
      if lg_mode_has "$mode" 002 || { [[ $sens == yes ]] && lg_mode_has "$mode" 004; }; then
        sev=CRITICAL
      elif lg_mode_has "$mode" 020; then
        sev=HIGH
      else
        sev=MEDIUM
      fi
      bad=1
      lg_finding "$sev" PRM-001 "Insecure permissions on $p" \
        "Mode is $mode but should be $max or stricter." \
        "chmod $max $p" "$p  mode=$mode (max allowed $max)"
    fi
    if [[ -z $LG_ROOT ]]; then      # ownership is only meaningful on a live system
      owner=$(lg_owner "$f")
      if [[ -n $owner && $owner != root ]]; then
        bad=1
        lg_finding HIGH PRM-002 "Critical file $p not owned by root" \
          "Owner is '$owner'. A non-root owner can rewrite this file." \
          "chown root:root $p" "$p  owner=$owner"
      fi
    fi
  done
  (( bad )) || lg_pass PRM-001 "Critical system files have restrictive permissions"
}

_perms_world_writable() {
  local dirs=() d ww
  while IFS= read -r d; do dirs+=("$d"); done < <(_perms_dirs /etc /usr /bin /sbin /lib /lib64 /opt /root /boot)
  (( ${#dirs[@]} )) || return 0
  ww=$(find "${dirs[@]}" -xdev -type f -perm -0002 2>/dev/null | head -n 25)
  if [[ -n $ww ]]; then
    lg_finding HIGH PRM-003 "World-writable files in system directories" \
      "Any local user can modify these files, enabling privilege escalation or persistence." \
      "Remove world-write: chmod o-w <file>. Investigate why the permission was set." "$(lg_strip_root "$ww")"
  else
    lg_pass PRM-003 "No world-writable files in system directories"
  fi
}

# Allow-list of SUID/SGID binaries that ship with common distributions.
_perms_suid_allowed() {
  case $1 in
    sudo|sudoedit|su|passwd|chsh|chfn|newgrp|gpasswd|mount|umount|ping|ping6|fusermount|fusermount3|\
    ssh-keysign|unix_chkpwd|pam_timestamp_check|crontab|at|chage|expiry|wall|write|pkexec|\
    polkit-agent-helper-1|dbus-daemon-launch-helper|mount.nfs|Xorg.wrap|traceroute6.iputils|\
    ssh-agent|locate|plocate|mlocate|screen|staprun|snap-confine|ksu|userhelper|chsh.util-linux|\
    sg|newuidmap|newgidmap|bwrap|mtr-packet|unix2_chkpwd|utempter|postdrop|postqueue|opensshd) return 0 ;;
  esac
  return 1
}

_perms_suid_sgid() {
  local dirs=() d found f rel base high="" med=""
  while IFS= read -r d; do dirs+=("$d"); done < <(_perms_dirs /usr /bin /sbin /opt /home /tmp /var/tmp /dev/shm /srv /var/www /root)
  (( ${#dirs[@]} )) || return 0
  found=$(find "${dirs[@]}" -xdev -type f \( -perm -4000 -o -perm -2000 \) 2>/dev/null | head -n 200)
  while IFS= read -r f; do
    [[ -n $f ]] || continue
    rel=$(lg_strip_root "$f"); base=${rel##*/}
    case $rel in
      /tmp/*|/var/tmp/*|/dev/shm/*|/home/*|/srv/*|/var/www/*) high+="$rel  mode=$(lg_mode "$f")"$'\n' ;;
      *) _perms_suid_allowed "$base" || med+="$rel  mode=$(lg_mode "$f")"$'\n' ;;
    esac
  done <<<"$found"
  if [[ -n $high ]]; then
    lg_finding HIGH PRM-004 "SUID/SGID files in user-writable locations" \
      "Set-id binaries outside system paths are a classic privilege-escalation backdoor." \
      "Inspect each file (file, strings, package ownership) and remove the set-id bit: chmod u-s,g-s <file>." "$high"
  fi
  if [[ -n $med ]]; then
    lg_finding MEDIUM PRM-005 "Non-standard SUID/SGID binaries" \
      "These set-id files are not on LinuxGuard's allow-list of common system binaries." \
      "Verify each belongs to an installed package (dpkg -S / rpm -qf); remove the set-id bit if unnecessary." "$med"
  fi
  [[ -z $high && -z $med ]] && lg_pass PRM-004 "No unexpected SUID/SGID binaries"
  return 0
}

_perms_sticky() {
  local dirs=() d res sev=MEDIUM
  while IFS= read -r d; do dirs+=("$d"); done < <(_perms_dirs /etc /usr /opt /var /srv /home /root /bin /sbin /lib)
  (( ${#dirs[@]} )) || return 0
  res=$(find "${dirs[@]}" -xdev -type d -perm -0002 ! -perm -1000 2>/dev/null | head -n 25)
  if [[ -n $res ]]; then
    res=$(lg_strip_root "$res")
    grep -qE '^/(etc|usr|bin|sbin|lib)' <<<"$res" && sev=HIGH
    lg_finding "$sev" PRM-006 "World-writable directories without the sticky bit" \
      "Any user can delete or rename other users' files in these directories." \
      "chmod o-w <dir> (or chmod +t <dir> if shared write access is required)." "$res"
  else
    lg_pass PRM-006 "No world-writable directories without sticky bit"
  fi
}

_perms_home_dirs() {
  local d mode hi="" mid="" lo="" rel
  for d in "$LG_ROOT"/home/*/ "$LG_ROOT/root/"; do
    [[ -d $d ]] || continue
    d=${d%/}; mode=$(lg_mode "$d"); [[ -n $mode ]] || continue
    rel=$(lg_strip_root "$d")
    if lg_mode_has "$mode" 002; then hi+="$rel  mode=$mode"$'\n'
    elif lg_mode_has "$mode" 020; then mid+="$rel  mode=$mode"$'\n'
    elif lg_mode_has "$mode" 005; then lo+="$rel  mode=$mode"$'\n'
    fi
  done
  [[ -n $hi  ]] && lg_finding HIGH   PRM-007 "World-writable home directories" \
      "Other users can plant or replace files (e.g. shell rc files) in these homes." \
      "chmod 750 <home>" "$hi"
  [[ -n $mid ]] && lg_finding MEDIUM PRM-008 "Group-writable home directories" \
      "Members of the directory's group can modify its contents." "chmod 750 <home>" "$mid"
  [[ -n $lo  ]] && lg_finding LOW    PRM-009 "Home directories readable by other users" \
      "Other local users can list or read files in these homes." "chmod 750 <home>" "$lo"
  [[ -z $hi$mid$lo ]] && lg_pass PRM-007 "Home directories are not accessible by other users"
  return 0
}
