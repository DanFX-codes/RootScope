#!/usr/bin/env bash
# LinuxGuard test suite - dependency-free. Usage: bash tests/run_tests.sh
# Builds fixture roots, runs the CLI against them and exercises library helpers.
set -u
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export LG_HOME; LG_HOME=$(cd "$HERE/.." && pwd)
LG="$LG_HOME/linuxguard.sh"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

PASS=0 FAIL=0
ok()   { PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m %s\n' "$1"; }
section() { printf '\n== %s ==\n' "$1"; }

assert_eq()   { [[ $2 == "$3" ]] && ok "$1" || bad "$1 (expected '$3', got '$2')"; }
assert_has()  { grep -qF -- "$3" "$2" && ok "$1" || bad "$1 (missing: $3)"; }
assert_not()  { grep -qF -- "$3" "$2" && bad "$1 (unexpected: $3)" || ok "$1"; }
assert_true() { local d=$1; shift; "$@" && ok "$d" || bad "$d"; }
assert_false(){ local d=$1; shift; "$@" && bad "$d" || ok "$d"; }

# shellcheck source=tests/fixtures.sh
source "$HERE/fixtures.sh"
build_insecure_root "$TMP/bad"
build_hardened_root "$TMP/good"

# ---------------------------------------------------------------- CLI ------
section "CLI behaviour"
"$LG" --version >"$TMP/v.txt"; assert_has "--version prints version" "$TMP/v.txt" "LinuxGuard 1."
"$LG" --help >"$TMP/h.txt";    assert_has "--help lists options" "$TMP/h.txt" "--fail-on"
"$LG" --bogus >/dev/null 2>&1; assert_eq "unknown option exits 2" "$?" 2
"$LG" -m nope --root "$TMP/good" >/dev/null 2>&1; assert_eq "unknown module exits 2" "$?" 2
"$LG" --fail-on urgent --root "$TMP/good" >/dev/null 2>&1; assert_eq "invalid --fail-on exits 2" "$?" 2
"$LG" --root "$TMP/missing" >/dev/null 2>&1; assert_eq "missing --root exits 2" "$?" 2

# ------------------------------------------------- insecure system scan ----
section "Insecure fixture: detection and classification"
"$LG" --root "$TMP/bad" -o "$TMP/bad.md" -q --no-color; assert_eq "default exit code is 0" "$?" 0
"$LG" --root "$TMP/bad" -o "$TMP/bad2.md" -q --fail-on critical; assert_eq "--fail-on critical exits 1" "$?" 1
R="$TMP/bad.md"
expect() { assert_has "$1" "$R" "### [$2] $3 -"; }
expect "extra UID 0 account is CRITICAL"        CRITICAL USR-001
expect "empty password is CRITICAL"             CRITICAL USR-004
expect "duplicate UID is MEDIUM"                MEDIUM   USR-002
expect "system account shell is MEDIUM"         MEDIUM   USR-003
expect "MD5 password hash is MEDIUM"            MEDIUM   USR-005
expect "NOPASSWD: ALL is HIGH"                  HIGH     USR-006
expect "many admins is LOW"                     LOW      USR-007
expect "password aging is LOW"                  LOW      USR-008
expect "world-readable shadow is CRITICAL"      CRITICAL PRM-001
expect "world-writable system file is HIGH"     HIGH     PRM-003
expect "SUID in /home is HIGH"                  HIGH     PRM-004
expect "non-standard SUID is MEDIUM"            MEDIUM   PRM-005
expect "dir without sticky bit is MEDIUM"       MEDIUM   PRM-006
expect "world-writable home is HIGH"            HIGH     PRM-007
expect "telnet listener is CRITICAL"            CRITICAL NET-001
expect "unreviewed listeners are LOW"           LOW      NET-002
expect "ASLR disabled is MEDIUM"                MEDIUM   NET-003
expect "root SSH login is CRITICAL"             CRITICAL SSH-001
expect "empty SSH passwords is CRITICAL"        CRITICAL SSH-002
expect "SSH password auth is MEDIUM"            MEDIUM   SSH-003
expect "host-based auth is HIGH"                HIGH     SSH-005
expect "weak ciphers are HIGH"                  HIGH     SSH-008
expect "Include file honoured (grace time 0)"   MEDIUM   SSH-009
expect "private key perms are HIGH"             HIGH     SSH-011
expect "no firewall is HIGH"                    HIGH     FWS-001
expect "running telnet service is CRITICAL"     CRITICAL FWS-003
expect "brute force then login is CRITICAL"     CRITICAL AUTH-001
expect "high-volume brute force is HIGH"        HIGH     AUTH-002
expect "moderate brute force is MEDIUM"         MEDIUM   AUTH-003
expect "root password login is HIGH"            HIGH     AUTH-005
expect "break-in warning is HIGH"               HIGH     AUTH-010
assert_has "Match-block override is ignored (effective value reported)" "$R" "PasswordAuthentication yes"
assert_not "loopback redis is not flagged"       "$R" "tcp/6379"
assert_not "allow-listed SUID (passwd) skipped"  "$R" "/usr/bin/passwd  mode"
assert_has "attacker IP appears as evidence"     "$R" "203.0.113.50: 60 failed logins followed by a SUCCESSFUL login"
assert_has "overall risk is CRITICAL"            "$R" "**Overall risk: CRITICAL**"
assert_has "score floors at 0"                   "$R" "Security score: 0/100"

# --------------------------------------------------- hardened scan ---------
section "Hardened fixture: no false positives"
"$LG" --root "$TMP/good" -o "$TMP/good.md" -q --fail-on low; assert_eq "clean system exits 0 even with --fail-on low" "$?" 0
assert_has "score is 100"            "$TMP/good.md" "Security score: 100/100"
assert_has "no findings statement"   "$TMP/good.md" "No findings."
assert_not "no finding headings"     "$TMP/good.md" "### ["

# --------------------------------------------------------- report ----------
section "Report structure"
for h in "# LinuxGuard Security Audit Report" "## Executive summary" "### Results by module" \
         "## Critical findings" "## High findings" "## Medium findings" "## Low findings" \
         "## Passed checks" "## Notes and limitations" "## Methodology" "**Remediation:**" "**Evidence:**"; do
  assert_has "report contains '$h'" "$R" "$h"
done
assert_has "'Fix first' section lists priorities" "$R" "### Fix first"
FF=$(sed -n '/### Fix first/,/### Results/p' "$R")
assert_eq "'Fix first' lists Criticals before Highs (5 Critical, 0 High here)" \
  "$(grep -c 'CRITICAL' <<<"$FF")/$(grep -c 'HIGH' <<<"$FF")" "5/0"

# -------------------------------------------------------- module filter ----
section "Module selection"
"$LG" --root "$TMP/bad" -m ssh,users -o "$TMP/sub.md" -q
assert_has "selected module runs" "$TMP/sub.md" "SSH-001"
assert_not "unselected module skipped" "$TMP/sub.md" "NET-001"
assert_not "unselected module skipped (authlog)" "$TMP/sub.md" "AUTH-001"

# ------------------------------------------------- offline w/o snapshot ----
section "Offline mode without runtime snapshot"
rm -rf "$TMP/nosnap"; build_hardened_root "$TMP/nosnap"; rm -rf "$TMP/nosnap/_cmd"
"$LG" --root "$TMP/nosnap" -o "$TMP/nosnap.md" -q
assert_not "no false 'no firewall' finding" "$TMP/nosnap.md" "FWS-001 - No active"
assert_has "limitation is documented in notes" "$TMP/nosnap.md" "runtime snapshot"

# ------------------------------------------------------- thresholds --------
section "Brute-force threshold"
LG_BRUTE_THRESHOLD=500 "$LG" --root "$TMP/bad" -o "$TMP/thr.md" -q
assert_not "high threshold suppresses IP findings" "$TMP/thr.md" "AUTH-003 -"

# ------------------------------------------------------------ unit tests ---
section "Library unit tests"
export LG_ROOT=""
# shellcheck source=lib/common.sh
source "$LG_HOME/lib/common.sh"; source "$LG_HOME/lib/ssh.sh"; source "$LG_HOME/lib/network.sh"
LG_QUIET=1

assert_true  "lg_mode_exceeds: 644 > 640" lg_mode_exceeds 644 640
assert_false "lg_mode_exceeds: 600 <= 640" lg_mode_exceeds 600 640
assert_true  "lg_mode_exceeds: setuid bit exceeds 755" lg_mode_exceeds 4755 755
assert_true  "lg_mode_has: other-write in 666" lg_mode_has 666 002
assert_false "lg_mode_has: no other-write in 660" lg_mode_has 660 002

LG_MODULE=unit
lg_finding BOGUS X-1 t d f 2>/dev/null; assert_eq "invalid severity rejected" "$?" 1
lg_finding CRITICAL T-1 t d f; lg_finding HIGH T-2 t d f; lg_finding MEDIUM T-3 t d f; lg_finding LOW T-4 t d f
assert_eq "score = 100-25-10-4-1" "$(lg_score)" 60
assert_eq "overall = CRITICAL" "$(lg_overall)" CRITICAL
assert_eq "total findings" "$(lg_total_findings)" 4
assert_true "lg_any_at_least HIGH" lg_any_at_least HIGH

_net_classify tcp 23;   assert_eq "port 23 -> CRITICAL" "$NET_SEV" CRITICAL
_net_classify tcp 3306; assert_eq "port 3306 -> HIGH"   "$NET_SEV" HIGH
_net_classify udp 514;  assert_eq "udp/514 -> MEDIUM (syslog)" "$NET_SEV" MEDIUM
_net_classify tcp 514;  assert_eq "tcp/514 -> HIGH (rsh)" "$NET_SEV" HIGH
_net_classify tcp 22;   assert_eq "port 22 -> acceptable" "$NET_SEV" ""
_net_classify tcp 31337; assert_eq "unknown port -> LOW" "$NET_SEV" LOW

assert_eq "ssh seconds: 2m" "$(_ssh_seconds 2m)" 120
assert_eq "ssh seconds: 45"  "$(_ssh_seconds 45)" 45
LG_ROOT="$TMP/bad"; SSHC=(); _ssh_parse_file "$LG_ROOT/etc/ssh/sshd_config"
assert_eq "ssh parser: first value wins, Match ignored" "${SSHC[passwordauthentication]}" yes
assert_eq "ssh parser: Include followed" "${SSHC[logingracetime]:-}" 0
assert_eq "ssh parser: keys lower-cased" "${SSHC[permitrootlogin]}" yes

printf '\nResults: %d passed, %d failed\n' "$PASS" "$FAIL"
(( FAIL == 0 ))
