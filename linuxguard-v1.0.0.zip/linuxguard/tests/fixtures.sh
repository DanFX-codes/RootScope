#!/usr/bin/env bash
# Builds synthetic root filesystems for offline audits. Permissions are applied
# at build time (git does not preserve them), so nothing sensitive is committed.
# shellcheck shell=bash

_w() { mkdir -p "$(dirname "$1")"; cat > "$1"; }   # write stdin to path

# Generate syslog-style lines: _log <count> <template with %d for index>
_gen() { local i; for (( i = 1; i <= $1; i++ )); do printf "$2\n" "$i"; done; }

build_insecure_root() {
  local r=$1
  mkdir -p "$r"
  echo "vulnbox" | _w "$r/etc/hostname"
  echo 'PRETTY_NAME="Test Linux (insecure fixture)"' | _w "$r/etc/os-release"

  _w "$r/etc/passwd" <<'X'
root:x:0:0:root:/root:/bin/bash
toor:x:0:0:backdoor:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
backup:x:34:34:backup:/var/backups:/bin/bash
alice:x:1000:1000::/home/alice:/bin/bash
bob:x:1000:1001::/home/bob:/bin/bash
X
  _w "$r/etc/shadow" <<'X'
root:$6$salt$hashhashhash:19000:0:99999:7:::
toor:$6$salt$hashhashhash:19000:0:99999:7:::
alice::19000:0:99999:7:::
bob:$1$salt$md5cryptmd5crypt:19000:0:99999:7:::
daemon:*:19000:0:99999:7:::
X
  chmod 644 "$r/etc/shadow"
  _w "$r/etc/group" <<'X'
root:x:0:
sudo:x:27:alice,bob,carol,dave
X
  _w "$r/etc/sudoers" <<'X'
Defaults env_reset
root ALL=(ALL:ALL) ALL
alice ALL=(ALL) NOPASSWD: ALL
X
  chmod 644 "$r/etc/sudoers"
  _w "$r/etc/sudoers.d/90-bob" <<'X'
bob ALL=(ALL) NOPASSWD: /usr/bin/systemctl
X
  _w "$r/etc/login.defs" <<'X'
PASS_MAX_DAYS 99999
X
  chmod 644 "$r/etc/passwd" "$r/etc/group"

  _w "$r/etc/ssh/sshd_config" <<'X'
Include /etc/ssh/sshd_config.d/*.conf
PermitRootLogin yes
PasswordAuthentication yes
PermitEmptyPasswords yes
X11Forwarding yes
MaxAuthTries 10
Ciphers aes128-cbc,3des-cbc
MACs hmac-md5,hmac-sha2-256
HostbasedAuthentication yes
Match User sftp
    PasswordAuthentication no
X
  echo "LoginGraceTime 0" | _w "$r/etc/ssh/sshd_config.d/10-local.conf"
  mkdir -p "$r/root/.ssh"
  echo "ssh-ed25519 AAAAC3Nza fixture@test" | _w "$r/root/.ssh/authorized_keys"
  chmod 664 "$r/root/.ssh/authorized_keys"
  printf -- '-----BEGIN OPENSSH PRIVATE KEY-----\nZmFrZQ==\n-----END OPENSSH PRIVATE KEY-----\n' | _w "$r/root/.ssh/id_ed25519"
  chmod 644 "$r/root/.ssh/id_ed25519"

  # permissions: world-writable file/dir, SUID backdoors, open homes
  echo "#!/bin/sh" | _w "$r/etc/cron.daily/cleanup"; chmod 666 "$r/etc/cron.daily/cleanup"
  mkdir -p "$r/opt/shared"; chmod 777 "$r/opt/shared"
  printf 'x' | _w "$r/usr/bin/passwd"; chmod 4755 "$r/usr/bin/passwd"          # allow-listed
  printf 'x' | _w "$r/usr/local/bin/oddsuid"; chmod 4755 "$r/usr/local/bin/oddsuid"
  printf 'x' | _w "$r/home/alice/rootshell"; chmod 4755 "$r/home/alice/rootshell"
  chmod 777 "$r/home/alice"; mkdir -p "$r/home/bob"; chmod 755 "$r/home/bob"

  # kernel parameters
  echo 1 | _w "$r/proc/sys/net/ipv4/ip_forward"
  echo 0 | _w "$r/proc/sys/net/ipv4/tcp_syncookies"
  echo 1 | _w "$r/proc/sys/net/ipv4/conf/all/accept_source_route"
  echo 0 | _w "$r/proc/sys/kernel/randomize_va_space"

  # runtime snapshot: no firewall, risky listeners and services
  _w "$r/_cmd/ss" <<'X'
Netid State  Recv-Q Send-Q Local Address:Port Peer Address:Port Process
tcp   LISTEN 0      128    0.0.0.0:22         0.0.0.0:*     users:(("sshd",pid=812,fd=3))
tcp   LISTEN 0      128    0.0.0.0:23         0.0.0.0:*     users:(("telnetd",pid=900,fd=4))
tcp   LISTEN 0      80     0.0.0.0:3306       0.0.0.0:*     users:(("mysqld",pid=950,fd=22))
tcp   LISTEN 0      128    127.0.0.1:6379     0.0.0.0:*     users:(("redis-server",pid=960,fd=6))
tcp   LISTEN 0      128    [::]:9999          [::]:*        users:(("custom",pid=970,fd=7))
udp   UNCONN 0      0      0.0.0.0:111        0.0.0.0:*     users:(("rpcbind",pid=400,fd=5))
X
  _w "$r/_cmd/systemctl_running" <<'X'
ssh.service     loaded active running OpenBSD Secure Shell server
telnet.service  loaded active running Telnet server
vsftpd.service  loaded active running FTP server
cron.service    loaded active running Cron
X

  # auth log: brute force + compromise + noise
  {
    _gen 60 'Nov 14 10:00:%02d vulnbox sshd[111]: Failed password for root from 203.0.113.50 port 4444 ssh2'
    echo 'Nov 14 11:00:00 vulnbox sshd[112]: Accepted password for alice from 203.0.113.50 port 5555 ssh2'
    _gen 120 'Nov 14 12:00:00 vulnbox sshd[113]: Failed password for invalid user admin%d from 192.0.2.99 port 22 ssh2'
    _gen 12 'Nov 14 13:00:%02d vulnbox sshd[114]: Failed password for bob from 198.51.100.7 port 22 ssh2'
    _gen 15 'Nov 14 14:00:%02d vulnbox sshd[115]: Invalid user oracle%d from 198.51.100.8 port 22'
    echo 'Nov 14 15:00:00 vulnbox sshd[116]: Accepted password for root from 10.0.0.9 port 22 ssh2'
    _gen 6 'Nov 14 15:10:%02d vulnbox sudo: pam_unix(sudo:auth): authentication failure; logname=bob uid=1001 euid=0'
    echo 'Nov 14 15:20:00 vulnbox useradd[200]: new user: name=support, UID=1005, GID=1005, home=/home/support, shell=/bin/bash'
    echo 'Nov 14 15:30:00 vulnbox sshd[117]: reverse mapping checking getaddrinfo for x failed - POSSIBLE BREAK-IN ATTEMPT!'
  } | _w "$r/var/log/auth.log"
}

build_hardened_root() {
  local r=$1
  mkdir -p "$r"
  echo "hardbox" | _w "$r/etc/hostname"
  echo 'PRETTY_NAME="Test Linux (hardened fixture)"' | _w "$r/etc/os-release"
  _w "$r/etc/passwd" <<'X'
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
sync:x:4:65534:sync:/bin:/bin/sync
alice:x:1000:1000::/home/alice:/bin/bash
X
  _w "$r/etc/shadow" <<'X'
root:!:19000:0:90:7:::
daemon:*:19000:0:99999:7:::
alice:$y$j9T$salt$hashhashhash:19000:0:90:7:::
X
  chmod 640 "$r/etc/shadow"
  printf 'root:x:0:\nsudo:x:27:alice\n' | _w "$r/etc/group"
  echo '%sudo ALL=(ALL:ALL) ALL' | _w "$r/etc/sudoers"; chmod 440 "$r/etc/sudoers"
  echo 'PASS_MAX_DAYS 90' | _w "$r/etc/login.defs"
  chmod 644 "$r/etc/passwd" "$r/etc/group"

  _w "$r/etc/ssh/sshd_config" <<'X'
PermitRootLogin no
PasswordAuthentication no
PermitEmptyPasswords no
X11Forwarding no
MaxAuthTries 3
LoginGraceTime 30
AllowUsers alice
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com
X
  chmod 600 "$r/etc/ssh/sshd_config"
  mkdir -p "$r/home/alice/.ssh"; chmod 750 "$r/home/alice"
  echo "ssh-ed25519 AAAAC3Nza alice@laptop" | _w "$r/home/alice/.ssh/authorized_keys"; chmod 600 "$r/home/alice/.ssh/authorized_keys"
  printf -- '-----BEGIN OPENSSH PRIVATE KEY-----\nZmFrZQ==\n-----END OPENSSH PRIVATE KEY-----\n' | _w "$r/home/alice/.ssh/id_ed25519"
  chmod 600 "$r/home/alice/.ssh/id_ed25519"
  mkdir -p "$r/root"; chmod 700 "$r/root"
  printf 'x' | _w "$r/usr/bin/sudo"; chmod 4755 "$r/usr/bin/sudo"
  mkdir -p "$r/tmp"; chmod 1777 "$r/tmp"

  echo 0 | _w "$r/proc/sys/net/ipv4/ip_forward"
  echo 1 | _w "$r/proc/sys/net/ipv4/tcp_syncookies"
  echo 0 | _w "$r/proc/sys/net/ipv4/conf/all/accept_source_route"
  echo 2 | _w "$r/proc/sys/kernel/randomize_va_space"

  _w "$r/_cmd/ss" <<'X'
tcp LISTEN 0 128 0.0.0.0:22      0.0.0.0:* users:(("sshd",pid=812,fd=3))
tcp LISTEN 0 128 [::]:22         [::]:*    users:(("sshd",pid=812,fd=4))
udp UNCONN 0 0   127.0.0.53%lo:53 0.0.0.0:* users:(("systemd-resolve",pid=500,fd=13))
tcp LISTEN 0 128 127.0.0.1:6379  0.0.0.0:* users:(("redis-server",pid=960,fd=6))
X
  _w "$r/_cmd/ufw" <<'X'
Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), disabled (routed)
New profiles: skip

To                         Action      From
22/tcp                     ALLOW IN    Anywhere
X
  _w "$r/_cmd/systemctl_running" <<'X'
ssh.service      loaded active running OpenBSD Secure Shell server
cron.service     loaded active running Cron
fail2ban.service loaded active running Fail2Ban
auditd.service   loaded active running Security Auditing Service
X
  _w "$r/var/log/auth.log" <<'X'
Nov 14 09:00:01 hardbox sshd[10]: Failed password for alice from 192.0.2.10 port 4000 ssh2
Nov 14 09:00:05 hardbox sshd[10]: Failed password for alice from 192.0.2.10 port 4000 ssh2
Nov 14 09:01:00 hardbox sshd[11]: Accepted publickey for alice from 192.0.2.10 port 4001 ssh2
X
}
