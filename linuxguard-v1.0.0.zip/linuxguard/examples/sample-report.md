# LinuxGuard Security Audit Report

| Field | Value |
|---|---|
| Host | `vulnbox` |
| Operating system | Test Linux (insecure fixture) |
| Kernel | n/a (offline audit) |
| Scan mode | Offline audit of `<offline-root>` |
| Generated | 2026-11-14T17:57:04Z |
| Run as | `root` |
| LinuxGuard | v1.0.0 |

## Executive summary

**Overall risk: CRITICAL** · **Security score: 0/100** · 50 finding(s), 1 check(s) passed

| Severity | Findings |
|---|---:|
| Critical | 9 |
| High | 13 |
| Medium | 18 |
| Low | 10 |

### Fix first

- **CRITICAL** `USR-001` Non-root account with UID 0
- **CRITICAL** `USR-004` Accounts with an empty password
- **CRITICAL** `PRM-001` Insecure permissions on /etc/shadow
- **CRITICAL** `PRM-001` Insecure permissions on /etc/sudoers
- **CRITICAL** `NET-001` Exposed telnet service on tcp/23

### Results by module

| Module | Passed | Critical | High | Medium | Low |
|---|---:|---:|---:|---:|---:|
| User & Privilege Auditing | 0 | 2 | 1 | 3 | 2 |
| File Permission Auditing | 0 | 2 | 3 | 2 | 1 |
| Network & Listening Port Inspection | 0 | 1 | 1 | 4 | 2 |
| SSH Security Auditing | 0 | 2 | 4 | 4 | 2 |
| Firewall & Service Auditing | 0 | 1 | 1 | 1 | 2 |
| Authentication Log Analysis | 1 | 1 | 3 | 4 | 1 |

## Critical findings (9)

### [CRITICAL] USR-001 - Non-root account with UID 0

- **Module:** users
- **Description:** Accounts with UID 0 have full root privileges. Only 'root' should have it.
- **Remediation:** Remove or renumber the account (userdel / usermod -u), then investigate how it was created.

**Evidence:**

```text
toor (uid 0)
```

### [CRITICAL] USR-004 - Accounts with an empty password

- **Module:** users
- **Description:** An empty password field allows login without a password (where PAM/SSH permit it).
- **Remediation:** Lock or set a password immediately: passwd -l <account> or passwd <account>.

**Evidence:**

```text
alice
```

### [CRITICAL] PRM-001 - Insecure permissions on /etc/shadow

- **Module:** perms
- **Description:** Mode is 644 but should be 640 or stricter.
- **Remediation:** chmod 640 /etc/shadow

**Evidence:**

```text
/etc/shadow  mode=644 (max allowed 640)
```

### [CRITICAL] PRM-001 - Insecure permissions on /etc/sudoers

- **Module:** perms
- **Description:** Mode is 644 but should be 440 or stricter.
- **Remediation:** chmod 440 /etc/sudoers

**Evidence:**

```text
/etc/sudoers  mode=644 (max allowed 440)
```

### [CRITICAL] NET-001 - Exposed telnet service on tcp/23

- **Module:** network
- **Description:** telnet is listening on 0.0.0.0: sends credentials and sessions in cleartext.
- **Remediation:** Disable telnet and use SSH.

**Evidence:**

```text
tcp  0.0.0.0:23  process=telnetd
```

### [CRITICAL] SSH-001 - SSH permits direct root login with a password

- **Module:** ssh
- **Description:** PermitRootLogin yes exposes the most targeted account to online password guessing.
- **Remediation:** Set 'PermitRootLogin no' (or prohibit-password) and use sudo from a named account.

**Evidence:**

```text
PermitRootLogin yes
```

### [CRITICAL] SSH-002 - SSH allows empty passwords

- **Module:** ssh
- **Description:** Accounts with blank passwords can log in over the network.
- **Remediation:** Set 'PermitEmptyPasswords no'.

**Evidence:**

```text
PermitEmptyPasswords yes
```

### [CRITICAL] FWS-003 - Risky service running: telnet

- **Module:** firewall
- **Description:** Telnet transmits credentials in cleartext.
- **Remediation:** systemctl disable --now telnet  (or remove the package if unused).

**Evidence:**

```text
telnet.service
```

### [CRITICAL] AUTH-001 - Successful login from an IP with brute-force history

- **Module:** authlog
- **Description:** A source that hammered SSH with failures later authenticated - the account may have been guessed.
- **Remediation:** Treat as a probable compromise: kill sessions, rotate credentials, review ~/.ssh/authorized_keys, cron and new users, then block the IP.

**Evidence:**

```text
203.0.113.50: 60 failed logins followed by a SUCCESSFUL login (alice/password)
```

## High findings (13)

### [HIGH] USR-006 - Passwordless sudo for ALL commands

- **Module:** users
- **Description:** NOPASSWD: ALL (or !authenticate) turns any compromise of that account into instant root.
- **Remediation:** Remove NOPASSWD/!authenticate (use visudo) or restrict to specific, non-shell commands.

**Evidence:**

```text
/etc/sudoers:alice ALL=(ALL) NOPASSWD: ALL
```

### [HIGH] PRM-003 - World-writable files in system directories

- **Module:** perms
- **Description:** Any local user can modify these files, enabling privilege escalation or persistence.
- **Remediation:** Remove world-write: chmod o-w <file>. Investigate why the permission was set.

**Evidence:**

```text
/etc/cron.daily/cleanup
```

### [HIGH] PRM-004 - SUID/SGID files in user-writable locations

- **Module:** perms
- **Description:** Set-id binaries outside system paths are a classic privilege-escalation backdoor.
- **Remediation:** Inspect each file (file, strings, package ownership) and remove the set-id bit: chmod u-s,g-s <file>.

**Evidence:**

```text
/home/alice/rootshell  mode=4755
```

### [HIGH] PRM-007 - World-writable home directories

- **Module:** perms
- **Description:** Other users can plant or replace files (e.g. shell rc files) in these homes.
- **Remediation:** chmod 750 <home>

**Evidence:**

```text
/home/alice  mode=777
```

### [HIGH] NET-001 - Exposed mysql/mariadb service on tcp/3306

- **Module:** network
- **Description:** mysql/mariadb is listening on 0.0.0.0: database/cache service reachable from the network; often unauthenticated by default.
- **Remediation:** Bind to 127.0.0.1 or a private interface and firewall the port.

**Evidence:**

```text
tcp  0.0.0.0:3306  process=mysqld
```

### [HIGH] SSH-005 - Trust-based SSH features enabled

- **Module:** ssh
- **Description:** HostbasedAuthentication and PermitUserEnvironment weaken authentication and can bypass restrictions.
- **Remediation:** Set both to 'no'.

**Evidence:**

```text
HostbasedAuthentication yes
PermitUserEnvironment no
```

### [HIGH] SSH-008 - Weak SSH ciphers, MACs or key exchange configured

- **Module:** ssh
- **Description:** CBC ciphers, MD5/SHA-1 MACs and legacy DH groups are vulnerable to known attacks.
- **Remediation:** Remove the weak algorithms or delete the directive to use OpenSSH's secure defaults.

**Evidence:**

```text
Ciphers aes128-cbc,3des-cbc
MACs hmac-md5,hmac-sha2-256
```

### [HIGH] SSH-011 - SSH private keys readable by other users

- **Module:** ssh
- **Description:** Anyone who can read a private key can impersonate its owner (OpenSSH also refuses such keys).
- **Remediation:** chmod 600 <key>; consider the key compromised if the host is shared.

**Evidence:**

```text
/root/.ssh/id_ed25519  mode=644
```

### [HIGH] SSH-012 - authorized_keys writable by group/others

- **Module:** ssh
- **Description:** Others can add their own public key and gain access as that user.
- **Remediation:** chmod 600 <file>

**Evidence:**

```text
/root/.ssh/authorized_keys  mode=664
```

### [HIGH] FWS-001 - No active host firewall detected

- **Module:** firewall
- **Description:** No ufw, firewalld, nftables or iptables ruleset restricts inbound traffic.
- **Remediation:** Enable one: 'ufw default deny incoming && ufw allow OpenSSH && ufw enable' or 'systemctl enable --now firewalld'.

**Evidence:**

```text
no active ruleset found
```

### [HIGH] AUTH-002 - High-volume SSH brute-force sources

- **Module:** authlog
- **Description:** These addresses made at least 50 failed attempts each.
- **Remediation:** Block at the firewall, enable fail2ban/sshguard, and move to key-only authentication.

**Evidence:**

```text
192.0.2.99: 120 failed logins
```

### [HIGH] AUTH-005 - Root logged in over SSH with a password

- **Module:** authlog
- **Description:** Direct password logins to root bypass accountability and are the top brute-force payoff.
- **Remediation:** Disable root password login and verify the activity was legitimate.

**Evidence:**

```text
root logged in with a password from 10.0.0.9 (1 time(s))
```

### [HIGH] AUTH-010 - SSH 'POSSIBLE BREAK-IN ATTEMPT' warnings

- **Module:** authlog
- **Description:** sshd flagged 1 connection(s) whose reverse DNS does not match the forward lookup.
- **Remediation:** Review the matching log lines and block the sources.

**Evidence:**

```text
warnings: 1
```

## Medium findings (18)

### [MEDIUM] USR-002 - Duplicate UIDs in /etc/passwd

- **Module:** users
- **Description:** Accounts that share a UID share all file ownership and privileges, defeating accountability.
- **Remediation:** Assign each account a unique UID (usermod -u) and fix file ownership (find / -uid OLD -exec chown NEW {} +).

**Evidence:**

```text
UID 0 shared by: root,toor
UID 1000 shared by: alice,bob
```

### [MEDIUM] USR-003 - System accounts with an interactive login shell

- **Module:** users
- **Description:** Service accounts (UID < 1000) should not be able to log in interactively.
- **Remediation:** Set the shell to /usr/sbin/nologin: usermod -s /usr/sbin/nologin <account>.

**Evidence:**

```text
backup (uid 34) -> /bin/bash
```

### [MEDIUM] USR-005 - Weak password hashing algorithm in use

- **Module:** users
- **Description:** MD5-crypt and DES-crypt hashes are trivially crackable with modern hardware.
- **Remediation:** Set ENCRYPT_METHOD to YESCRYPT/SHA512 in /etc/login.defs and force a password change for affected users.

**Evidence:**

```text
bob (MD5-crypt)
```

### [MEDIUM] PRM-005 - Non-standard SUID/SGID binaries

- **Module:** perms
- **Description:** These set-id files are not on LinuxGuard's allow-list of common system binaries.
- **Remediation:** Verify each belongs to an installed package (dpkg -S / rpm -qf); remove the set-id bit if unnecessary.

**Evidence:**

```text
/usr/local/bin/oddsuid  mode=4755
```

### [MEDIUM] PRM-006 - World-writable directories without the sticky bit

- **Module:** perms
- **Description:** Any user can delete or rename other users' files in these directories.
- **Remediation:** chmod o-w <dir> (or chmod +t <dir> if shared write access is required).

**Evidence:**

```text
/opt/shared
/home/alice
```

### [MEDIUM] NET-001 - Exposed rpcbind service on udp/111

- **Module:** network
- **Description:** rpcbind is listening on 0.0.0.0: RPC portmapper aids reconnaissance and amplification attacks.
- **Remediation:** Disable rpcbind unless NFS/NIS is required.

**Evidence:**

```text
udp  0.0.0.0:111  process=rpcbind
```

### [MEDIUM] NET-003 - ASLR is not fully enabled

- **Module:** network
- **Description:** kernel.randomize_va_space=0 (expected 2). Memory-corruption exploits become far easier.
- **Remediation:** sysctl -w kernel.randomize_va_space=2 and persist it in /etc/sysctl.d/.

**Evidence:**

```text
kernel.randomize_va_space = 0
```

### [MEDIUM] NET-004 - TCP SYN cookies disabled

- **Module:** network
- **Description:** The host is more vulnerable to SYN-flood denial of service.
- **Remediation:** sysctl -w net.ipv4.tcp_syncookies=1

**Evidence:**

```text
net.ipv4.tcp_syncookies = 0
```

### [MEDIUM] NET-005 - Source-routed packets are accepted

- **Module:** network
- **Description:** Source routing lets an attacker dictate packet paths and spoof trusted hosts.
- **Remediation:** sysctl -w net.ipv4.conf.all.accept_source_route=0

**Evidence:**

```text
net.ipv4.conf.all.accept_source_route = 1
```

### [MEDIUM] SSH-003 - SSH password authentication enabled

- **Module:** ssh
- **Description:** Passwords are exposed to brute-force and credential stuffing; public keys are far stronger.
- **Remediation:** Deploy public keys, then set 'PasswordAuthentication no' (and 'KbdInteractiveAuthentication no').

**Evidence:**

```text
PasswordAuthentication yes
```

### [MEDIUM] SSH-006 - High MaxAuthTries (10)

- **Module:** ssh
- **Description:** Many attempts per connection make online guessing cheaper.
- **Remediation:** Set 'MaxAuthTries 3' or 4.

**Evidence:**

```text
MaxAuthTries 10
```

### [MEDIUM] SSH-009 - No login grace time limit

- **Module:** ssh
- **Description:** LoginGraceTime 0 lets unauthenticated connections stay open indefinitely (resource exhaustion).
- **Remediation:** Set 'LoginGraceTime 30'.

**Evidence:**

```text
LoginGraceTime 0
```

### [MEDIUM] SSH-013 - Root has authorized SSH keys

- **Module:** ssh
- **Description:** Keys in /root/.ssh/authorized_keys allow direct root access that bypasses sudo logging.
- **Remediation:** Remove unneeded keys; prefer named accounts plus sudo.

**Evidence:**

```text
/root/.ssh/authorized_keys
```

### [MEDIUM] FWS-003 - Risky service running: vsftpd

- **Module:** firewall
- **Description:** FTP sends credentials in cleartext.
- **Remediation:** systemctl disable --now vsftpd  (or remove the package if unused).

**Evidence:**

```text
vsftpd.service
```

### [MEDIUM] AUTH-003 - SSH brute-force sources detected

- **Module:** authlog
- **Description:** These addresses made at least 10 failed attempts each.
- **Remediation:** Enable fail2ban/sshguard and disable password authentication.

**Evidence:**

```text
198.51.100.7: 12 failed logins
```

### [MEDIUM] AUTH-004 - Repeated failed logins for root

- **Module:** authlog
- **Description:** 60 failed attempts targeted the root account.
- **Remediation:** Set PermitRootLogin no and block offending sources.

**Evidence:**

```text
root: 60 failed password attempts
```

### [MEDIUM] AUTH-006 - Invalid-user probing (username enumeration)

- **Module:** authlog
- **Description:** 15 attempts used usernames that do not exist - typical of automated scanners.
- **Remediation:** Rate-limit with fail2ban; restrict logins with AllowUsers/AllowGroups.

**Evidence:**

```text
oracle0 (15 attempts)
```

### [MEDIUM] AUTH-007 - Repeated sudo authentication failures

- **Module:** authlog
- **Description:** 6 sudo failures were logged; a local account may be compromised or misused.
- **Remediation:** Review who ran sudo (grep sudo /var/log/auth.log) and reset affected passwords.

**Evidence:**

```text
sudo failures: 6
```

## Low findings (10)

### [LOW] USR-007 - Large number of administrators (4)

- **Module:** users
- **Description:** Every sudo-capable account is a path to root; keep the set small (least privilege).
- **Remediation:** Remove users that do not need administrative access from the sudo/wheel/admin group.

**Evidence:**

```text
sudo: alice,bob,carol,dave
```

### [LOW] USR-008 - Passwords never (or rarely) expire

- **Module:** users
- **Description:** PASS_MAX_DAYS is 99999. Long-lived passwords extend the usefulness of any leaked credential.
- **Remediation:** Set PASS_MAX_DAYS to 365 or less in /etc/login.defs (and chage -M for existing users).

**Evidence:**

```text
PASS_MAX_DAYS 99999
```

### [LOW] PRM-009 - Home directories readable by other users

- **Module:** perms
- **Description:** Other local users can list or read files in these homes.
- **Remediation:** chmod 750 <home>

**Evidence:**

```text
/home/bob  mode=755
/root  mode=755
```

### [LOW] NET-002 - Unreviewed services listening on all/external interfaces

- **Module:** network
- **Description:** Each exposed listener enlarges the attack surface.
- **Remediation:** Confirm each service is required; bind others to 127.0.0.1 or stop them.

**Evidence:**

```text
tcp/9999 on :: (custom)
```

### [LOW] NET-006 - IPv4 forwarding is enabled

- **Module:** network
- **Description:** Expected on routers, VPN gateways and container hosts; unexpected elsewhere.
- **Remediation:** sysctl -w net.ipv4.ip_forward=0 if this host is not a router.

**Evidence:**

```text
net.ipv4.ip_forward = 1
```

### [LOW] SSH-007 - X11 forwarding enabled

- **Module:** ssh
- **Description:** X11 forwarding exposes the client's display to the server.
- **Remediation:** Set 'X11Forwarding no' unless needed.

**Evidence:**

```text
X11Forwarding yes
```

### [LOW] SSH-010 - No AllowUsers/AllowGroups restriction

- **Module:** ssh
- **Description:** Any valid local account may attempt SSH login.
- **Remediation:** Add 'AllowGroups ssh-users' (or AllowUsers) to limit who may connect.

**Evidence:**

```text
AllowUsers/AllowGroups not set
```

### [LOW] FWS-004 - No brute-force protection service running

- **Module:** firewall
- **Description:** Nothing automatically blocks hosts that repeatedly fail authentication.
- **Remediation:** Install and enable fail2ban, sshguard or crowdsec.

**Evidence:**

```text
fail2ban/sshguard/crowdsec not running
```

### [LOW] FWS-005 - Linux audit daemon (auditd) not running

- **Module:** firewall
- **Description:** Without auditd there is no kernel-level record of security-relevant events.
- **Remediation:** Install and enable auditd (apt install auditd / dnf install audit).

**Evidence:**

```text
auditd not running
```

### [LOW] AUTH-009 - User accounts created in the log window

- **Module:** authlog
- **Description:** New accounts are a common persistence technique.
- **Remediation:** Verify each account creation was authorised.

**Evidence:**

```text
support
```

## Passed checks (1)

- [x] `AUTH-008` No su authentication failures

## Notes and limitations

- _authlog_: Analysed /var/log/auth.log: 192 failed SSH logins, 15 invalid-user probes (brute-force threshold: 10 failures per IP).

## Methodology

LinuxGuard performs **read-only** checks; it never changes system state.

Each finding is classified Critical, High, Medium or Low. The security score starts at 100 and subtracts **25** per Critical, **10** per High, **4** per Medium and **1** per Low finding (minimum 0). The overall risk label is the highest severity present.

_Generated by LinuxGuard v1.0.0. Automated checks are a baseline, not a substitute for a full security assessment._
